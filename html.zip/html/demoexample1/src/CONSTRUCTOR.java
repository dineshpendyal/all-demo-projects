class employee
{
	int eid;
	String name;
	}
public class CONSTRUCTOR {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		employee e1=new employee1(10,"ntt1");
		employee e2=new employee1(20,"ntt1");
		employee e3=new employee1(30,"ntt1");
		
		System.out.println(e1.eid);
		System.out.println(e2.eid);
		
		
		// TODO Auto-generated method stub

	}

}
