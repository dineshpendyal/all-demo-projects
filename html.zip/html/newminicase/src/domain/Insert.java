package domain;






import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Insert {



	
	public static void main(String[] args) {
		try
		{
		   Class.forName("oracle.jdbc.driver.OracleDriver");
		   Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","TRDBNTT","TRDBNTT");
		   PreparedStatement st=con.prepareStatement("INSERT INTO ROLE VALUES('1','Admin')");
		   PreparedStatement st1=con.prepareStatement("INSERT INTO ROLE VALUES('2','Student')");
		   PreparedStatement st2=con.prepareStatement("INSERT INTO USERDETAILS VALUES('4746','ghazi','abbbas','2')");
		  PreparedStatement st3=con.prepareStatement("INSERT INTO USERDETAILS VALUES('4745','dinesh','dinesh123','1')");
		PreparedStatement st4=con.prepareStatement("INSERT INTO DEPARTMENT VALUES('123','cse')");
	PreparedStatement st5=con.prepareStatement("INSERT INTO DEPARTMENT VALUES('321','ece')");
			 //PreparedStatement st6=con.prepareStatement("INSERT INTO DEPARTMENT VALUES(45,'EEE')");
		PreparedStatement st7=con.prepareStatement("INSERT INTO PROFESSOR VALUES('1516','inayatulla',123)");
		   PreparedStatement st8=con.prepareStatement("INSERT INTO PROFESSOR VALUES('1518','shahabuddin',123)");
		   PreparedStatement st9=con.prepareStatement("INSERT INTO COURSE VALUES('1','JAVA',1518)");
		   PreparedStatement st10=con.prepareStatement("INSERT INTO COURSE VALUES('2','os',1516)");
		   PreparedStatement st11=con.prepareStatement("INSERT INTO STUDENT VALUES('1','aadarsh','ameerpet','02/12/1997','btech')");
		   PreparedStatement st12=con.prepareStatement("INSERT INTO STUDENT VALUES('2','ghazifazalabbas','habsiguda','26/04/1997','btech')");
		   PreparedStatement st13=con.prepareStatement("INSERT INTO STUDENT VALUES('3','thirupati','guntur','08/08/1997','btech')");
		   PreparedStatement st14=con.prepareStatement("INSERT INTO STUD_COURSE VALUES('1','2','ONE')");
		   PreparedStatement st15=con.prepareStatement("INSERT INTO STUD_COURSE VALUES('2','1','TWO')");

		   
		 st.executeQuery();
		st1.executeQuery();   
		 st2.executeQuery();
		 st3.executeQuery();

			 st4.executeQuery();
			 st5.executeQuery();
		//	st6.executeQuery();
			st7.executeQuery();
		  st8.executeQuery();
		   st9.executeQuery();
		   st10.executeQuery();
		 st11.executeQuery();
			  st12.executeQuery();
			 st13.executeQuery();
			 st14.executeQuery();
			 st15.executeQuery();




con.close();
	}
		catch(Exception e)
		{
			e.printStackTrace();

		}

}
}
