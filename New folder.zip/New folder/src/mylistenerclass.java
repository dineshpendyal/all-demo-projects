import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


public class mylistenerclass implements ServletContextListener {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		// TODO Auto-generated method stub

		sce.getServletContext().removeAttribute("INIT_KEY1");
		sce.getServletContext().removeAttribute("INIT_KEY2");

	}
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		// TODO Auto-generated method stub
		sce.getServletContext().setAttribute("INIT_KEY1","init_value1");
		sce.getServletContext().setAttribute("INIT_KEY2","init_value2");
		
		
		
	}

	


}
