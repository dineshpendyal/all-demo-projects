package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Logger;

import dbfw.ResultMapper;

import dbcon.ConnectionHolder;
import dbcon.DBConnectionException;
import dbfw.DBFWException;
import dbfw.DBHelper;
import dbfw.ParamMapper;
//import com.nttdata.course.domain.Country;
import domain.User;

public class UserDAO {
	public static void main(String[] args) 
	{
//Logger log=Logger.getLogger(UserDAO.class);
	
Scanner sc=new Scanner(System.in);
System.out.println("Enter the username");
String username=sc.next();
System.out.println("Enter the password");
String password=sc.next();
	}
	public User validateUser(final String username,final String password) throws DBFWException, CourseDAOException, DBConnectionException
	{
		User user=null;

	
	
		ConnectionHolder ch=null;
		Connection con=null;
		List roleid=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			final ParamMapper paramobj=new ParamMapper()
	        {
		        public void mapParam(PreparedStatement preStmt) throws SQLException 
		        {
			   System.out.println("in setting values to prepared statement");
		        preStmt.setString(1, username);
			    preStmt.setString(2, password);
			   
				}
		
	          };
	    
	         // System.out.println("in user validate");
			//log.debug("fetchig");
			//roleid=DBHelper.executeSelect(con,SQLMapper.FETCHROLEID,SQLMapper.USERMAPPER,FETCHROLEID);
	          //roleid = DBHelper.executeSelect(con,SQLMapper.FETCHROLEID,SQLMapper.USSERMAPPER,FETCHROLEID);
	       //   roleid = DBHelper.executeSelect(con, SQLMapper.FETCHROLEID, outMap, inMap);
	          roleid = DBHelper.executeSelect(con,SQLMapper.FORROLEID,SQLMapper.USSERMAPPER,paramobj);
	          System.out.println(roleid);
//			System.out.println(roleid);
			Iterator itr=roleid.iterator();
			while(itr.hasNext())
			{
				
				//System.out.println(itr.next());
				 user=(User) itr.next();
				if(User.getUserId().equals(username)&&User.getPassword().equals(password))
				{
					return  user;
				}
				
				else if(User.getUserId()!=username)
				{
					System.out.println("incorrect username");;
					//return null;
				}
				
			}
		
					
			
		} 
		catch (DBConnectionException e)
		{
			throw new DBConnectionException("not a user");
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		return  user;
		
	}
}
