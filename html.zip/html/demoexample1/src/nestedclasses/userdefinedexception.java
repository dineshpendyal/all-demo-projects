package nestedclasses;

class employeentt extends Exception
{
	int age;
	
void userException(employeentt e) throws employeentt
{
	if(e.age<18)
	{
		throw new employeentt();
	}
}

}

public class userdefinedexception {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
employeentt e1=new employeentt();
e1.age=16;
try{
	e1.userException(e1);	
}
catch(employeentt e)
{
	System.out.println("userdefined exception");
	
}
	}

}
