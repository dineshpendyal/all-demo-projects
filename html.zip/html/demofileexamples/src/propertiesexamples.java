import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;


public class propertiesexamples {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

Properties prop=new Properties();
Properties prop2=new Properties();
prop.setProperty("key", "value"); 
prop.setProperty("index", "onetwothree");
FileOutputStream infile=new FileOutputStream("connectproject.properties");
prop.store(infile, "writing to properties file");
FileInputStream in=new FileInputStream("connectproperties2.properties");
prop2.load(in);
//prop2.save();
System.out.println(prop2.getProperty("driver"));
System.out.println(prop2.getProperty("url"));
System.out.println(prop2.getProperty("user"));
System.out.println(prop2.getProperty("password"));


	}

}
