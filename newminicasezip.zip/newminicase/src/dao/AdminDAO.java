package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;

import dbcon.ConnectionHolder;
import dbcon.DBConnectionException;
import dbfw.DBFWException;
import dbfw.DBHelper;
import dbfw.ParamMapper;
import domain.Course;
import domain.Department;
import domain.Professor;
import domain.Student;
import domain.User;

public class AdminDAO {



public String saveProfessor(final Professor prof) throws DBFWException, CourseDAOException, DBConnectionException, SQLException
{	ConnectionHolder ch=null;
	Connection con=null;
	int  result=0;
	List pro=null;
	String ProfId=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
	              final ParamMapper SAVEPROFESSOR=new ParamMapper()
			        {
				        public void mapParam(PreparedStatement preStmt)throws SQLException 
				        {
					    preStmt.setString(1,prof.getProfId());
					    preStmt.setString(2,prof.getProfName());
					    preStmt.setString(3,prof.getDeptId());
						}
				
			        };
		result=DBHelper.executeUpdate(con,SQLMapper.SAVEPROFESSOR,SAVEPROFESSOR);
		//pro=DBHelper.executeSelect(con,SQLMapper.FETCHPROFESSOR,SQLMapper.PROFESSORMAPPER);
		//Iterator<String> itr=pro.iterator();
		//ProfId=itr.next();
		
	    } 
		catch (DBFWException e) {
			
			e.printStackTrace();
		} catch (DBConnectionException e) {
			
			e.printStackTrace();
		}
		
		finally{
			con.close();
			//System.out.println();
		}
			
		return ProfId;
		
		
		
		
		
		
	}



	public String saveCourse(final Course course) throws DBFWException, CourseDAOException, DBConnectionException
{
	ConnectionHolder ch=null;
	Connection con=null;
	int  result=0;
	List cour=null;
	String k=null;
	String CourseId=null;
		try {
			
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
	              final ParamMapper SAVECOURSE=new ParamMapper()
			        {
				        public void mapParam(PreparedStatement preStmt)
						throws SQLException 
				        {
					    preStmt.setString(1, course.getCourseId());
					    preStmt.setString(2, course.getCourseName());
					    preStmt.setString(3, course.getProfId());
						}
				
			          };
			result= DBHelper.executeUpdate(con,SQLMapper.SAVECOURSE,SAVECOURSE);
			//System.out.println(result);
		//cour= DBHelper.executeSelect(con,SQLMapper.FETCHCOURSE,SQLMapper.COURSEMAPPER);
	//	System.out.println(cour);
		
//		Iterator itr=cour.iterator();
//		while(itr.hasNext())
//		{
//			
//			System.out.println(itr.next());
//			
//			k=itr.toString(); 
//			System.out.println(k);
//	
////			return k;
//		}
//		
		
//	Iterator<String> itr=cour.iterator();
//		CourseId=itr.next();
		
	    } 
		catch (DBFWException e) {
			
			e.printStackTrace();
		} catch (DBConnectionException e) {
			
			e.printStackTrace();
		}
		return k;
		//return CourseId;
	
		
		
}	

public String saveStudent(final Student stud) throws DBFWException, CourseDAOException, DBConnectionException
{
	ConnectionHolder ch=null;
	Connection con=null;
	int  result=0;
	List stu=null;
	String StudentId=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
	              final ParamMapper SAVESTUDENT=new ParamMapper()
			        {
				        public void mapParam(PreparedStatement preStmt)
						throws SQLException 
				        {
				        	preStmt.setString(2,stud.getStudentName());
				        	preStmt.setString(1,stud.getStudId());
				        	preStmt.setString(3,stud.getAddress());
				        	preStmt.setDate(4,new java.sql.Date(stud.getDob().getTime()));
				        	preStmt.setString(5, stud.getDegree());

						}
				
			          };
		result= DBHelper.executeUpdate(con,SQLMapper.SAVESTUDENT,SAVESTUDENT );
		//System.out.println(result);
		//stu= DBHelper.executeSelect(con,SQLMapper.FETCHSTUDENT1,SQLMapper.STUDENTMAPPER);
		//PreparedStatement pstmt = 
		//ResultSet rs = pstmt.executeQuery(SQLMapper.FETCHSTUDENT1);
		
//		System.out.println(stu);
//		
//		Iterator itr=stu.iterator();
//		Student s=new Student();
//		while(itr.hasNext())
//		{  
//			
//			s=(Student)itr.next();
//			System.out.println(s);
//			
//		}
//		
		
//		
//		Iterator<String> itr=stu.iterator();
//		StudentId=itr.next();
		//System.out.println(StudentId);
		
	    } 
		catch (DBFWException e) {
			
			e.printStackTrace();
		} catch (DBConnectionException e) {
			
			e.printStackTrace();
		}
		
		//return s;
		return StudentId;
}


public List<Department> getAllDept() throws CourseDAOException,DBFWException, DBConnectionException
{
		List department=null;
		ConnectionHolder ch=null;
		Connection con=null;
		
 
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			//log.debug("fetchig");
			department= DBHelper.executeSelect(con,SQLMapper.FETCHDEPARTMENT,SQLMapper.DEPARTMENTMAPPER);
					
			
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db");
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return department;
		
	}
	

public List<Professor> getAllProf() throws DBFWException, CourseDAOException, DBConnectionException
{
	List professor=null;
	ConnectionHolder ch=null;
	Connection con=null;
	try {
		ch=ConnectionHolder.getInstance();
		con=ch.getConnection();
		
		//log.debug("fetchig");
		professor=DBHelper.executeSelect(con,SQLMapper.FETCHPROFESSOR,SQLMapper.PROFESSORMAPPER );
				
		
	} catch (DBConnectionException e) {
		throw new DBConnectionException("Unable to connect to db");
	
	}
	finally {

		try {

			if (con != null)
				con.close();

		} catch (SQLException e) {
		}
	}
	
	
	return professor;
}
}

