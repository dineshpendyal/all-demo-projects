package domain;

public class User {
private static String UserId;
private static String UserName;
private static String Password;
private static  String RoleId;
public User(String userId, String userName, String password, String roleId) {
	super();
	UserId = userId;
	UserName = userName;
	Password = password;
	RoleId = roleId;
}
public static String getUserId() {
	return UserId;
}
public static void setUserId(String userId) {
	UserId = userId;
}
public static String getUserName() {
	return UserName;
}
public static  void setUserName(String userName) {
	UserName = userName;
}
public static String getPassword() {
	return Password;
}
public static void setPassword(String password) {
	Password = password;
}
public static String getRoleId() {
	return RoleId;
}
public static void setRoleId(String roleId) {
	RoleId = roleId;
}
}
