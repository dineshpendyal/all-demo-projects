package com.nttdata.course.domain;

import java.util.Date;

public class student {

	private String studentid;
	private String studentname;
	private String address;
	private Date dob;
	private String degree;
	public String getStudentid() {
		return studentid;
	}
	public void setStudentid(String studentid) {
		this.studentid = studentid;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	
	
	
	
	
//	public student(String a,String b,String c,Date d,String e)
//	{
//		this.studentid=a;
//		this.studentname=b;
//		this.address=c;
//		this.dob=d;
//		this.degree=e;
//		
//		
//		
//	}
	
	
	
}
