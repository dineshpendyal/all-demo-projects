package inheritanceexamples;

public interface interestrate {
int giveinterest();
int x=10000;
}
