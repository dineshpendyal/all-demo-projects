package nestedclasses;

import java.util.Scanner;

public class exceptionexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a,b;
Scanner sc=new Scanner(System.in);
System.out.println("enter a");
a=sc.nextInt();
System.out.println("enter b");
b=sc.nextInt();
int res=0;
try{
	res=a/b;
	System.out.println(res);
	}
catch(ArithmeticException e)
{
	System.out.println("hello");	
}
catch(Exception e)
{
System.out.println("hello this is generic exception");	
}
	
	}

}
