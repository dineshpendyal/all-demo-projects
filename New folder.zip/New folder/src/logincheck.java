

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class logincheck
 */
@WebServlet("/logincheck")
public class logincheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public logincheck() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String str1=request.getParameter("text1");
		String str2=request.getParameter("text2");
		try
		{
			//Locale.setDefault(Locale.ENGLISH);
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","TRDBNTT","TRDBNTT");
			
			//ArrayList<String> list = new ArrayList<String>();
	 String sql = "select * from servletex where username='"+str1+"' and password='"+str2+"'";
//			 String sql = "select * from servletex where username=? and password=?";
	        System.out.println(sql);
			//Statement stmt = con.createStatement();
	        PreparedStatement pstmt=con.prepareStatement(sql);
	      
//	        pstmt.setString(1,str1);
//	        pstmt.setString(2,str2);
	        ResultSet rs=pstmt.executeQuery();
	        if(rs.next())
	        {
	        	//RequestDispatcher();
	        	System.out.println("succesfull login");
	        	response.sendRedirect("afterlogin.html");
	        	
	        }
	        else
	        {
	        	
	        	System.out.println("failed to login");
	        }
	        
//	           boolean k= pstmt.execute();
//	        if(k=true)
//	        {
//	        	System.out.println("valid user");
//	        	
//	        }
//	        else
//	        {
//	        	System.out.println("not a valid user");
//	        	
//	        }
//	        
	        
			//ResultSet rs= stmt.executeQuery(sql); 
//			Iterator itr = list.iterator();
//			while(itr.hasNext())
//			{
////				System.out.println(rs.getString('1'));
////				System.out.println(rs.getString('2'));
////				System.out.println(rs.getString('3'));
////				System.out.print(itr.next() + " "); 
//				//System.out.println(rs.getString(1)+"  "+rs.getString(2)+" "+rs.getString(3));
//			}
			
	         
		
			
		}
		catch(Exception e)
		{
			
			System.out.println(e);
			
		}
		
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
