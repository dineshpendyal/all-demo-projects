package inheritanceexamples;


class displayarrays{
	
	
void display(Integer[] x)
	{
	System.out.println("hello");
		for(Integer i:x)
		
	{
			
			System.out.println(i);
			
		}
		}
	
	
	void display(Float[] F)
	{
		for(Float i:F)
			
		{
			System.out.println(i);
			
	}
		}
	
	void display(Double[] x)
	{
		for(Double i:x)
			
		{
			System.out.println(i);
			
		}
		}
	
	void display(String[] x)
	{
		for(String i:x)
			
		{
			System.out.println(i);
			
		}
		}
	

	<E> void display(E[] e)
	{
	for(E i:e)
	{
		
		System.out.println(i);
	}
	}

	
}



public class overloadingexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Integer[] intArray={10,20,30,40,50};
	Float[] floatArray={10.1f,20.0f,30.5f,};
	String[] stringArray={"string1","string2","string3"};
	Double[] doubleArray={10.998,20.998};
	displayarrays da=new displayarrays();
	//da.display(floatArray);
	//da.display(stringArray);
	//da.display(doubleArray);
	da.display(intArray);
	
	}

}
