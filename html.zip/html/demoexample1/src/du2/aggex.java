package du2;

public class aggex {

	int area(int n){  
		  return n*n;	
		  
	}  

}
