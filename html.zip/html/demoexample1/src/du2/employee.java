package du2;

interface inter1
{
	

}

interface inter2
{
	
}


public class employee implements inter1,Comparable{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Class obj=employee.class;
	employee e1=new employee();
	
	Object o=new Object();
	System.out.println(Comparable.class.isAssignableFrom(obj));
	System.out.println(inter2.class.isAssignableFrom(obj));
	System.out.println();
	o=e1;
			o=obj.getInterfaces();
			o.getClass();
			
			System.out.println(obj.getName());
			
	
	
		
	}

	public int compareTo(Object arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

}
