//package com.nttdata.collectionExamples;
package inheritanceexamples;
import java.util.HashMap;
import java.util.Map;

public class partandseats {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String,Integer> m1=new HashMap<String,Integer>();

Map m2=new HashMap();
Map m3=new HashMap();
Map m4=new HashMap();
Map m5=new HashMap();
m1.put("bjp",352);
m2.put("congress",52);
m3.put("ysr",23);
m4.put("tdp",200);
m5.put("jds",1);


m1.putAll(m2);
m1.putAll(m3);
m1.putAll(m4);
m1.putAll(m5);
System.out.println("ysrcp");
System.out.println(m1.containsKey("tmc"));
System.out.println();

System.out.println(m1.containsKey(10));
System.out.println(m1.containsKey(20));
System.out.println(m1.containsKey(100));
System.out.println(m1.containsKey(200));
System.out.println(m1.containsKey(200));

for(Map.Entry m:m1.entrySet())
{
	System.out.println(m.getKey()+" "+m.getValue());
	}
m1.remove(10);	

System.out.println("after remove");
for(Map.Entry m:m1.entrySet())
{
	System.out.println(m.getKey()+" "+m.getValue());}
	}
	
}
