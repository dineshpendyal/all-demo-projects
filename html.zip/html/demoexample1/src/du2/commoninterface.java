package du2;

public interface commoninterface {
final int x=0;
final int y=0;
abstract  void read(int x,int y);

abstract void calculate(int x,int y);

}
