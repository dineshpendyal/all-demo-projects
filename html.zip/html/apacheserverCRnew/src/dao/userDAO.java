package dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;


import dbcon.ConnectionHolder;
import dbcon.DBConnectionException;
import dbfw.DBFWException;
import dbfw.DBHelper;
import domain.user;

public class userDAO {
public user validateUser(String userId,String passwd) throws CourseDAOException, SQLException, ClassNotFoundException
{      user user01 = null;
       String username;
       String password;
       String rollId;
       
		Class.forName("oracle.jdbc.driver.OracleDriver");
	
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","TRDB","TRDB");

		Statement stmt=con.createStatement();
		//stmt.executeUpdate("insert into ntdata values(100)");
		
			  
     
	 if (userId != null) {
            //Statement stmt=con.createStatement();
          String sql = "Select * from userdetails where userId='" + userId + "'";
           ResultSet rs = stmt.executeQuery(sql);
          rs.next();
         username = rs.getString(2);
        password = rs.getString(3);
        rollId=rs.getString(4);
         //user01=new User(userId,username,password,rollId);
        user01=new user(userId,username,password,rollId);
        //System.out.println(userId+" "+username+" "+password+" "+rollId);
        } else{
        	//user01=new user("abc","abc","abc","abc");
        	System.out.println("entered else");
        }
           

   return user01;
}







}
