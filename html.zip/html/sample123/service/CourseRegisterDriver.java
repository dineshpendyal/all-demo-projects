
package com.nttdata.course.service;
//import java.sql.Date;
import java.util.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import com.nttdata.course.dao.AdminDAO;
import com.nttdata.course.dao.StudentDAO;
import com.nttdata.course.dao.UserDAO;
import com.nttdata.course.dbcon.DBConnectionException;
import com.nttdata.course.dao.CourseDAOException;
import com.nttdata.course.dbfw.DBFWException;
import com.nttdata.course.domain.Course;
import com.nttdata.course.domain.CoursePreference;
import com.nttdata.course.domain.Professor;
import com.nttdata.course.domain.StudPreference;
import com.nttdata.course.domain.Student;
import com.nttdata.course.domain.User;


public class CourseRegisterDriver {

	public static void main(String[] args) throws DBFWException, CourseDAOException, IOException, DBConnectionException, ParseException
	{
		SimpleDateFormat abc=new SimpleDateFormat("yyyy/mm/dd");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("....Enter user id...");
		String userid=sc.next();
		
		System.out.println("...Enter password....");
		String password=sc.next();
		
		CourseRegFacade crf=new CourseRegFacade();
		User u1=null;
		String student="2";
		String admin="1";
		int z=0;
		try
		{
			String conti=null;
			u1=crf.validateUser(userid, password);
			System.out.println("RoleId  "+u1.getRoleId());
			
			conti=u1.getRoleId();
			
				if(conti.equals("admin")) 
				{
						
						System.out.println("admin logged in");   
						System.out.println("1.Add professor Details");
						System.out.println("2.Add Course Details");
						System.out.println("3.Add Student Details");
						
						String ch=sc.next(); 
						
						if(ch.equals("1"))
						{
							System.out.println("Enter professor Name");
							String pnme=sc.next();
							System.out.println("Enter the deptid");
							String did=sc.next();
							System.out.println("Enter the profid");
							String pid=sc.next();
							Professor p= new Professor(pid,pnme,did);
							String re=crf.saveProfessor(p);
							System.out.println("Professor details are saved");
							System.out.println("Professor ID generated "+re);
						}
						if(ch.equals("2"))
						{
							System.out.println("Enter CourseName");
							String cnme=sc.next();
							System.out.println("Enter the ProfID");
							String prid=sc.next();
							System.out.println("Enter the courseID");
							String crid=sc.next();
						
							Course c= new Course(crid,cnme,prid);
							c.getCourseId();
							c.getCourseName();
							c.getProfId();
							String cr=crf.saveCourse(c);
							System.out.println("Course details are saved");
							System.out.println("Course ID generated "+cr);
						}
						if(ch.equals("3"))
						{
							System.out.println("Enter the student name");
							String sn=sc.next();
							System.out.println("Enter the Student Address");
							String sad=sc.next();
							System.out.println("Enter the Student dob in the format(yyyy/mm/dd)");
							Date date = (Date)abc.parse(sc.next());
							
							System.out.println("Enter the student degree");
							String sde=sc.next();
							System.out.println("Enter the studentID");
							String sid=sc.next();
							Student st=new Student(sid,sn,sad,date,sde);
							String er=crf.saveStudent(st);
							System.out.println("Student details saved");
							System.out.println("Student id generated"+er);
						}
						
				
				System.out.println("Type to continue......yes/no");
				conti=sc.next().toLowerCase();	
				}
				// System.out.println("test");
				
				
				if(conti.equals("stud"))
				{
					System.out.println("student logged in");
					System.out.println("1.Get all courses");
					System.out.println("2.Save preference");
					System.out.println("3.get preferred courses");
					String ch1 =sc.next();
					if(ch1.equals("1"))
					{
						List<Course>allcou=new ArrayList<Course>();
						allcou=crf.getAllCourse();
						for(Course c:allcou)
						{
							System.out.println("Course ID "+c.getCourseId());
							System.out.println("Course name "+c.getCourseName());
							System.out.println("Professor ID "+c.getProfId());
						}
					}
					if(ch1.equals("2"))
					{
						System.out.println("Enter student ID");
						String sid=sc.next();
						System.out.println("Enter Course ID");
						String cid=sc.next();
						System.out.println("Enter course preference");
						String cpref=sc.next();
						
						CoursePreference cp=new CoursePreference(cid,cpref);
						List<CoursePreference>lcp=new ArrayList<CoursePreference>();
						
						
						lcp.add(cp);
						StudPreference sp=new StudPreference(sid,lcp);
						int w=CourseRegFacade.saveProfCourses(sp);

						
//						
					
//						int w=CourseRegFacade.saveProfCourses(sp);

						if(w!=0)
						{
							System.out.println("Student course preference saved successfully");
						}
						else
						{
							System.out.println("cannot register");
						}
						
					}
					if(ch1.equals("3"))
					{
						System.out.println("Enter student ID");
						String studID=sc.next();
						List<CoursePreference> course2=CourseRegFacade.getPrefCourse(studID);
						for(CoursePreference obj:course2)
						{
							System.out.println("Course :"+obj.getCourseId() +" Preference :"+  obj.getPreference() );
						}
					}
					
				}
			
		}
		catch(CourseRegException e)
		{
			System.out.println(e.getMessage());
		}
	}
}
