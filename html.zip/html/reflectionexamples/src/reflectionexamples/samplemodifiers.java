package reflectionexamples;

import java.lang.reflect.Modifier;

//package reflectionexamples;
public class samplemodifiers {

	
	public static void	printmodifiers(Object o)
	{
		Class c=o.getClass();
		int m=c.getModifiers();
		
		if(Modifier.isPublic(m))
		{
			System.out.println("public");
		}
		if(Modifier.isAbstract(m))
		{
			System.out.println("abstract");
		}
		if(Modifier.isFinal(m))
		{
			System.out.println("final");
		}
		
	}
	
	/**
	 * @param args
	 */
	
 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//kid k=new kid();
//printmodifiers(k);
	String str=new String();
	printmodifiers(str);
	
	}

}
