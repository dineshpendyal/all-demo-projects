
public class whileloopdemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String from = "copy this string until";
		StringBuffer to= new StringBuffer();
		int i=0;
		char c=from.charAt(i);
        //to.append(c);
        while(c!='y')
        {
        	to.append(c);
        	c=from.charAt(++i);
        	
        }
		System.out.print(from);
		
		System.out.print(to);

	}

}
