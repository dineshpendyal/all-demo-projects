package domain;

public class department {
	private String DepId;
	private String DeptName;
	public department(String depId, String deptName) {
		super();
		DepId = depId;
		DeptName = deptName;
	}
	public String getDepId() {
		return DepId;
	}
	public void setDepId(String depId) {
		DepId = depId;
	}
	public String getDeptName() {
		return DeptName;
	}
	public void setDeptName(String deptName) {
		DeptName = deptName;
	}
	

}