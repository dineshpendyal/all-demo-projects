package inheritanceexamples;

public class sbiclass implements interestrate{

	/**
	 * @param args
	 */
	

	public int giveinterest() {
		int ir=(int)(x*0.10f);
		return ir;

		// TODO Auto-generated method stub
		
	}

}
