package abstarctclass;

public class class1 {

	
	
public	static void display()
	{
		
		System.out.println("hello");
		
	}
	
	
	/**
	 * @param args
	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}
//
}
