

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class loginchecktosite
 */
@WebServlet("/loginchecktosite")
public class loginchecktosite extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginchecktosite() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String str1=request.getParameter("text1");
		String str2=request.getParameter("text2");
		try
		{
			//Locale.setDefault(Locale.ENGLISH);
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","TRDBNTT","TRDBNTT");
			HttpSession session=request.getSession();
			String n=request.getParameter("text1");
			session.setAttribute("uname", n);
			//ArrayList<String> list = new ArrayList<String>();
	 String sql = "select * from usercarddetails where username='"+str1+"' and password='"+str2+"'";
//			 String sql = "select * from servletex where username=? and password=?";
	        System.out.println(sql);
			//Statement stmt = con.createStatement();
	        PreparedStatement pstmt=con.prepareStatement(sql);
	      
//	        pstmt.setString(1,str1);
//	        pstmt.setString(2,str2);
	        ResultSet rs=pstmt.executeQuery();
	        if(rs.next())
	        {
	        	
	        	System.out.println("succesfull login");
	        	response.sendRedirect("afterlogintosite.html");
	        	
	        }
	        else
	        {
	        	
	        	System.out.println("failed to login try again");
	        }
	  
			
		}
		catch(Exception e)
		{
			
			System.out.println(e);
			
		}
	
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
