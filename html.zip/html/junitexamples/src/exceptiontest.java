
public class exceptiontest {

public int divide(int x,int y) throws myexception
{
	int	result=0;
	try{
		if(y==0)
		{
			throw new myexception();
		}
		else
		{
		result=x/y;
		}
	}
	catch(NullPointerException e)
	{
		
		
	}
	return result;
}
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}
