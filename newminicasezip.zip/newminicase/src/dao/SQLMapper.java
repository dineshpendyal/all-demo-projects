package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import dbfw.ParamMapper;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import dbfw.ResultMapper;
import domain.Course;
import domain.CoursePreference;
import domain.Department;
import domain.Professor;
import domain.Student;
import domain.User;
import java.lang.Object;



public class SQLMapper {
	public class USSERMAPPER {

	}
	//public static final String FETCHROLEID=
		//"select * from country_081";
	public static final String FORROLEID=
		"select * from userdetails where Username=? and Password=?";
	public static final String SAVEPROFESSOR=
		"insert into Professor values(?,?,?)";
	
	public static final String SAVECOURSE=
			"insert into course values(?,?,?)";
	public static final String SAVESTUDENT=
			"insert into student values(?,?,?,?,?)";
	public static final String FETCHDEPARTMENT=
			"select * from department";
	public static final String FETCHPROFESSOR=
			"select * from professor";
	public static final String FETCHCOURSE=
			"select * from course";
	public static final String FETCHSTUDENT1=
			"select * from student where studid=? ";
	
	
	public static final String FETCHSTUDENT=
			"select * from student ";
	public static final String FETCHPREFERREDCOURSE=
			"select  * from stud_course";
	public static final String SAVEPREFERENCE=
			"insert into stud_course values(?,?,?)";
	public static final String FETCHSTUD_COURSE=
			"select count(preference) from stud_course";
//public static final String NUMBERMAPPER=
	//	"select count(Preference) from Stud_Course";
	
//	public static final ResultMapper NUMBERMAPPER=
//			new ResultMapper() {
//		public int mapRow1(ResultSet rs) throws SQLException {
//			int count=rs.getInt(1);
//			return count;
//		//return ("select count(Preference) from Stud_Course");
//	}
//
//		
//	};
	
	
	
	public static final ResultMapper COURSEMAPPER2=new ResultMapper()
		{
			public Object mapRow(ResultSet rs) throws SQLException {
			String Studid=rs.getString(1);
			String CourseId=rs.getString(2);
			String Preference=rs.getString(3);
			
			CoursePreference c=new CoursePreference(Studid,CourseId,Preference);
			return c;
			}
			
		};
		
	
	
	
	
	public static final ResultMapper NUMBERMAPPER = new ResultMapper()
	{

		public Object mapRow(ResultSet rs) throws SQLException {
			// TODO Auto-generated method stub
			return null;
		}
//		public Object mapRow(ResultSet rs) throws SQLException
//		{
//			
//			User u=new User(rs.getString("userid"),rs.getString("username"),rs.getString("password"),rs.getString("roleid"));
//			return u;
//		}
	};
	
	
	
	
//	public static final ResultMapper COUNTRYMAPPER=
//			new ResultMapper()
//		{
//			public Object mapRow(ResultSet rs) throws SQLException {
//			int id=	rs.getInt(1);
//			String name=rs.getString(2);
//			Country c=new Country(id,name);
//				return c;
//			}
//	
	
	
	
	
	public static final ResultMapper USSERMAPPER = new ResultMapper()
	{
		public Object mapRow(ResultSet rs) throws SQLException
		{
			
			User u=new User(rs.getString("userid"),rs.getString("username"),rs.getString("password"),rs.getString("roleid"));
//			List k=u;
//			System.out.println(k);
			//System.out.println(rs.getString("userid"));
			return u;
		}
	};
//	public static final ResultMapper PROFESSORMAPPER=new ResultMapper()
//		{
//			public Object mapRow(ResultSet rs) throws SQLException {
//			String ProfId=rs.getString(1);
//		Object o=null;
//		o=ProfId;	
//		return o;
//			return ProfId;
//			}
//			
//		};
//		
		
		public static final ResultMapper PROFESSORMAPPER=new ResultMapper()
		{
		
		
			public Object mapRow(ResultSet rs) throws SQLException 
			{
			String ProfessorId=	rs.getString(1);
			//System.out.println(ProfessorId);
			//second is giving sheela name but how? and why?-->getstring(1) is giving id of sheela spm it is first row
//			String ProfessorName=rs.getString(2);
//			String DepartmentId=rs.getString(3);
			//Professor c=new Professor(ProfessorId,ProfessorName,DepartmentId);
			//Professor c=new Professor(ProfessorId);
			return ProfessorId;
			}
			
		};
		
		
		
		public static final ResultMapper COURSEMAPPER=new ResultMapper()
			{
				public Object mapRow(ResultSet rs) throws SQLException
				{
				
				String Courseid=rs.getString(1);
				
				String Coursename=rs.getString(2);
				String profid=rs.getString(3);
				Course c=new Course(Courseid, Coursename, profid);
				return c;
				}
				
			};
			public static final ResultMapper STUDENTMAPPER=new ResultMapper()
				{
					public Object mapRow(ResultSet rs) throws SQLException 
					{
					String Studentid=rs.getString(1);
					String Studentname=rs.getString(2);
					String Studentaddress=rs.getString(3);
					Date Studentdob=rs.getDate(4);
					String Studentdegree=rs.getString(5);
					Student s=new Student(Studentid,Studentname,Studentaddress,Studentdob,Studentdegree);

					//Student s=new Student(String Studentid,String Studentname,String Studentaddress,Date Studentdob,String studentdegree);
					//return Studentid;
					return s;
					}
					
				};
				public static final ResultMapper DEPARTMENTMAPPER=new ResultMapper()
					{
					
					public Object mapRow(ResultSet rs) throws SQLException
						{
						String DepartmentId=rs.getString(1);
						String DepartmentName=rs.getString(2);
						
						Department c=new Department(DepartmentId,DepartmentName);
						return c;
						}
						
					};
					
								
}
