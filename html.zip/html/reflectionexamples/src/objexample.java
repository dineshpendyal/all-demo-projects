





public class objexample {

	
	public Object example()
	{
		//int x=0;
		Integer x = null;
		String k="hello";
		return x;
		
		
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	objectexample o=new objectexample();
	o.example();
	String s=o.toString();
	System.out.println(s);
	
	}

}
