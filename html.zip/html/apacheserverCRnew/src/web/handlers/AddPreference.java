package web.handlers;


import service.*;


//import java.beans.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import dbcon.DBConnectionException;
import dbfw.DBFWException;
import mvc.HttpRequestHandler;
import dao.adminDAO;
//import com.keane.training.dao.CourseDAO;
import dao.CourseDAOException;
import dao.DAOAppException;
import dao.RegisterDAO;
import dao.studentDAO;
import domain.course;
import domain.professor;
import domain.user;
import domain.coursepreference;
import domain.studentpreference;

public class AddPreference implements HttpRequestHandler {
	static Logger log = Logger.getLogger(RegisterUser.class);

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session=request.getSession(true);
		
		
		try{
			String isExists;
			studentDAO dao = new studentDAO();
			String sid=request.getParameter("txtstudid");
			String cid=request.getParameter("txtcourseid");
			String pref=request.getParameter("txtpreferences");
			coursepreference cp=new coursepreference(cid,pref);
			
			List<coursepreference>lcp=new ArrayList<coursepreference>();
			lcp.add(cp);
			request.setAttribute("addpreference", lcp);
			//session.setAttribute("preferredcourses", lcp);
			
			studentpreference sp=new studentpreference(sid,lcp);
			isExists = sid;
			if (isExists==null)
			{
				//log.info("Professor already registered");
				RequestDispatcher dispatcher = request.getRequestDispatcher("..\\pages\\error.jsp");
				request.setAttribute("Err","Course already registered with the system");
				dispatcher.forward(request, response);
			}
			else
			{
				System.out.println("hi hello");
				dao.saveCoursePref(sp);
				RequestDispatcher dispatcher = request.getRequestDispatcher("..\\pages\\savepreferencessuccess.jsp");
				request.setAttribute("Success","Course successfully registered with the system");
				dispatcher.forward(request, response);
			}
		
		}catch (CourseDAOException e) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
			request.setAttribute("Err", e.getMessage());
			dispatcher.forward(request, response);
		}
	}}
