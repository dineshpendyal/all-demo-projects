class professor{
	int average;
	professor avgmarks(student s)
	{
	float avg=0;
	int sum=0;
	for(int x:s.marks)
	{
	sum+=x;	

	}
		
	avg=sum/s.marks.length;
	professor p=new professor();
	p.average=(int)avg;
	return p;	
	}

	}
	
	








class student
{
int sid;
String name;
int[] marks={10,20,30,40,50};

public student(String x,int y)
{
	name=x;
	sid=y;
}
}

public class passingobjectasparameter {

	/**
	 * @param args
	 */
public static void main(String[] args) {
		// TODO Auto-generated method stub

	float a=0;
	//student s=new student("name1", 100);
	//student s2=new student("name2", 200);
	//a=s.avgmarks(s2);
	professor p=new professor();
	professor p1=new professor();
	
	}

}
