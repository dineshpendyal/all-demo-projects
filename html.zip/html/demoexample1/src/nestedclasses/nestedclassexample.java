package nestedclasses;
class company{
	int companyid;
	String name;
class nttdata
{
int salary;
void salarydetails()
{
	System.out.println(this.salary);
}

}
static class nttdataser2
{
	int salary;
	void salarydetails()
	{
		System.out.println(this.salary);
	}
}


}



public class nestedclassexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
company c1=new company();
company.nttdata n1=c1.new nttdata();
n1.salary=20000;
n1.salarydetails();
company.nttdataser2 s1=new company.nttdataser2();
	
	}

}
