package com.nttdata.course.service;

public class infraappexception {

	public void courseregexception(String message,Throwable cause)
	{
		
		System.out.println("course reg exception");
		System.out.println(message);
		System.out.println(cause);
		
	}
	public void courseregexceptiopn(String s)
	{
		System.out.println("exception is");
		System.out.println(s);
		
	}
	
	
	

}
