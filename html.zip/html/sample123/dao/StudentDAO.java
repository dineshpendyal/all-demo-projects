package com.nttdata.course.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import com.nttdata.course.dbcon.ConnectionHolder;
import com.nttdata.course.dbcon.DBConnectionException;
import com.nttdata.course.dbfw.DBFWException;
import com.nttdata.course.dbfw.DBHelper;
import com.nttdata.course.dbfw.ParamMapper;
import com.nttdata.course.domain.Course;
import com.nttdata.course.domain.CoursePreference;
import com.nttdata.course.domain.StudPreference;

public class StudentDAO {

	
private static final String MAParamMapper = null;
public List<Course> getAllCourse() throws DBFWException, CourseDAOException, DBConnectionException
{
	List Course=null;
	ConnectionHolder ch=null;
	Connection con=null;
	

	
	try {
		ch=ConnectionHolder.getInstance();
		con=ch.getConnection();
		
		
		Course= DBHelper.executeSelect(con,SQLMapper.FETCHCOURSE,SQLMapper.COURSEMAPPER1);
				
		
	} catch (DBConnectionException e) {
		throw new DBConnectionException("Unable to get all courses");
	
	}
	finally {

		try {

			if (con != null)
				con.close();

		} catch (SQLException e) {
		}
	}
	
	
	return Course;
	
}


public int saveCoursePref( StudPreference studPref) throws DBFWException, CourseDAOException, DBConnectionException
{
	ConnectionHolder ch=null;
	Connection con=null;
	int  result=0;
	List count=null;
	int noofentries=studPref.getprefCourse().size();
	
	
		
	               ParamMapper SAVEPREFERENCE=new ParamMapper()
			        {
				        public void mapParam(PreparedStatement preStmt)
						throws SQLException 
				        {
				        	preStmt.setString(1, studPref.getStudId());		
				        	preStmt.setString(2, ((CoursePreference) studPref.getprefCourse().get(0)).getCourseId());	
				        	preStmt.setString(3, ((CoursePreference) studPref.getprefCourse().get(0)).getPreference());	
						}
				
			          };
			          try {
			        	  ch=ConnectionHolder.getInstance();
			        	  con=ch.getConnection();
			        	  int pre=DBHelper.executeUpdate(con,SQLMapper.SAVEPREFERENCE,SAVEPREFERENCE );  
			            count = DBHelper.executeSelect(con,SQLMapper.FETCHSTUD_COURSE,SQLMapper.NUMBERMAPPER);
			            Iterator itr=count.iterator();
			    	       result=(int) itr.next();
			          }
			          
		catch (DBFWException e) {
			
			e.printStackTrace();
			
		}
		catch (DBConnectionException e) {
			
			e.printStackTrace();
		}
	//}
			          
		
		return result;
	
}


public List<CoursePreference> getPrefCourse(String studId) throws DBFWException, CourseDAOException, DBConnectionException
{
	List Course=null;
	
	ConnectionHolder ch=null;
	Connection con=null;
	
	try {
		ch=ConnectionHolder.getInstance();
		con=ch.getConnection();
		
		Course= DBHelper.executeSelect(con,SQLMapper.FETCHPREFERREDCOURSE,SQLMapper.COURSEMAPPER2);
		return Course;
	   
	} 
	catch (DBConnectionException e)
	{
		throw new DBConnectionException("Unable to connect");
	}
	finally {

		try {

			if (con != null)
				con.close();

		} catch (SQLException e) {
		}
	}

	
	
}
}



