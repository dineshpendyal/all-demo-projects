package arrayofobjectsexamples;
import java.util.Scanner;


public class userandpass {
	String[] users={"user1","user2"};
	String[] passwords={"password1","password2"};

	System.out.println("enter username");
	String user=sc.next();
	System.out.println("enter password");
	String pass=sc.next();
	for(int i=0;i<users.length;i++)
	{
	if(user[i].equals(user) && passwords[i].equals(pass))
	{
		System.out.println("welcome"+user);
		break;
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
