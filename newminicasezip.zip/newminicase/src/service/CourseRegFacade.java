package service;

import java.sql.SQLException;
import java.util.List;

import dao.AdminDAO;
import dao.CourseDAOException;
import dao.StudentDAO;
import dao.UserDAO;
import dbcon.DBConnectionException;
import dbfw.DBFWException;
import domain.Course;
import domain.CoursePreference;
import domain.Department;
import domain.Professor;
import domain.StudPreference;
import domain.Student;
import domain.User;

public class CourseRegFacade {

	
		// TODO Auto-generated method stub
public static User validateUser(String userId,String passwd) throws CourseDAOException,DBFWException, CourseDAOException, DBConnectionException
{
	System.out.println("this is validate user");
	UserDAO obj= new UserDAO();
	System.out.println("after userdao object validate user");
User u=null;
u=obj.validateUser(userId,passwd);
System.out.println("after validatae user");
return u;
}
public  static String saveProfessor(Professor professor) throws CourseDAOException,DBFWException, CourseDAOException, DBConnectionException, SQLException
{
	AdminDAO obj1=new AdminDAO();
	
	return obj1.saveProfessor(professor);
}
public static String saveCourse(Course c) throws CourseDAOException,DBFWException, CourseDAOException, DBConnectionException
{
AdminDAO obj1=new AdminDAO();
	
	return obj1.saveCourse(c);
}
public static String saveStudent(Student s) throws CourseDAOException,DBFWException, CourseDAOException, DBConnectionException
{
AdminDAO obj1=new AdminDAO();
	
	return obj1.saveStudent(s);
}
public static List<Professor> getAllProf() throws CourseDAOException,DBFWException, CourseDAOException, DBConnectionException
{
AdminDAO obj1=new AdminDAO();
	
	return obj1.getAllProf();
}
public static List<Department> getAllDept() throws CourseDAOException,DBFWException, CourseDAOException, DBConnectionException
{
AdminDAO obj1=new AdminDAO();
	
	return obj1.getAllDept();
}
public static List<Course> getAllCourses() throws CourseDAOException,DBFWException, CourseDAOException, DBConnectionException
{
	StudentDAO obj2=new StudentDAO();
	return obj2.getAllCourse();
}
public static int saveProfCourses(StudPreference studpref) throws CourseDAOException,DBFWException, CourseDAOException, DBConnectionException
{
	StudentDAO obj2=new StudentDAO();
	return obj2.saveCoursePref(studpref);
}
public static List<CoursePreference> getPrefCourse(String studId) throws CourseDAOException,DBFWException, CourseDAOException, DBConnectionException
{
	StudentDAO obj2=new StudentDAO();
	return obj2.getPrefCourse(studId);
}
	}


