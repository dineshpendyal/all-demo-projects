package domain;

public class coursepreference {
	private String CourseId;
	private String PrefCourse;
	public coursepreference(String courseId, String prefCourse) {
		super();
		CourseId = courseId;
		PrefCourse = prefCourse;
	}
	public coursepreference() {
		// TODO Auto-generated constructor stub
	}
	public coursepreference(String id) {
		// TODO Auto-generated constructor stub
		CourseId=id;
	}
	public String getCourseId() {
		return CourseId;
	}
	public void setCourseId(String courseId) {
		CourseId = courseId;
	}
	public String getPrefCourse() {
		return PrefCourse;
	}
	public void setPrefCourse(String prefCourse) {
		PrefCourse = prefCourse;
	}
	
}
