package du3;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;


public class PropertiesTest1 {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 
	         Properties prop2=new Properties();
	         FileInputStream in=new FileInputStream("connect.properties");
	         prop2.load(in);
	         System.out.println(prop2.getProperty("user"));
	         System.out.println(prop2.getProperty("password"));
	         System.out.println(prop2.getProperty("floor"));
	         System.out.println(prop2.getProperty("location"));
	}

}