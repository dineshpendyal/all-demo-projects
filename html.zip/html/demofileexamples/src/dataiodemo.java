import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class dataiodemo {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
//try{
DataOutputStream out=new DataOutputStream(new FileOutputStream("invoice1.txt"));
	double[] prices={19.99,9.99,15.99,3.99,4.99};
	int[] units={12,8,13,29,50};
	String[] descs={"java T-shirt","java mug","java pin","ss","ssr"};
	for(int i=0;i<prices.length;i++)
		{
	out.writeDouble(prices[i]);
	out.writeChar('\t');
	out.writeInt(units[i]);
	out.writeChar('\t');
	out.writeChars(descs[i]);
	out.writeChar('\n');
DataInputStream in=new DataInputStream(new FileInputStream("invoice1.txt"));
double price;
int unit;
StringBuffer desc;

double total=0.0;

try
{
while(true)
{

price=in.readDouble();
in.readChar();
unit=in.readInt();
in.readChar();
char chr;
desc=new StringBuffer(20);
char lineSep='\n';
while((chr=in.readChar())!=lineSep)
desc.append(chr);

System.out.println("you have ordered"+unit+"units of"+desc+"at"+price);
total=total+unit*price;
}
}
catch(IOException e)
{
System.out.println("for a total of"+total);	


}
}

}
		
}
		
	


