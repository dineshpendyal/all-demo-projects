

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class servletrtodb
 */
@WebServlet("/servletrtodb")
public class servletrtodb extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servletrtodb() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String str1=request.getParameter("text1");
		String str2=request.getParameter("text2");
		String str3=request.getParameter("text3");
	//	String str4=request.getParameter("text4");
		//String str4[]=req.getParameterValues("hobbies");
	
		try
		{
			//Locale.setDefault(Locale.ENGLISH);
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","TRDBNTT","TRDBNTT");
			String sql;
	        sql = "insert into servletex values('"+str1+"','"+str2+"','"+str3+"')";
			Statement stmt = con.createStatement();
	        
			stmt.executeQuery(sql); 
			
	         
		
			
		}
		catch(Exception e)
		{
			
			System.out.println(e);
			
		}
		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
