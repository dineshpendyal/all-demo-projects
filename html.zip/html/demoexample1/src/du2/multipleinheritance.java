package du2;

import java.util.Scanner;

public class multipleinheritance implements commoninterface{

	
	
	/**
	 * @param args
	 */
	//public static void main(String[] args) {
		// TODO Auto-generated method stub
//final int x,y;
	//Scanner sc=new Scanner(System.in);
	//read(10,20);

	
	//}

public void read(int x,int y) {
		// TODO Auto-generated method stub
		
		System.out.println(x);
		System.out.println(y);
	}

	

	public void calculate(int x,int y) {
		// TODO Auto-generated method stub
	int k=x+y;
	System.out.println(k);
	}

}
