


class myexception extends Exception{
	
	//System.out.println();
}

public class userdefinedexceptionexample throws myexception{

	
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
