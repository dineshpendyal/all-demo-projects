package com.nttdata.course.service;

import java.util.List;

import com.nttdata.course.dao.AdminDAO;
import com.nttdata.course.dao.CourseDAOException;
import com.nttdata.course.dao.StudentDAO;
import com.nttdata.course.dao.UserDAO;
import com.nttdata.course.dbcon.DBConnectionException;
import com.nttdata.course.dbfw.DBFWException;
import com.nttdata.course.domain.Course;
import com.nttdata.course.domain.CoursePreference;
import com.nttdata.course.domain.Department;
import com.nttdata.course.domain.Professor;
import com.nttdata.course.domain.StudPreference;
import com.nttdata.course.domain.Student;
import com.nttdata.course.domain.User;

public class CourseRegFacade {

	
		// TODO Auto-generated method stub
public static User validateUser(String userId,String passwd) throws CourseRegException,DBFWException, CourseDAOException, DBConnectionException
{
	System.out.println("hii nttdata");
	UserDAO obj= new UserDAO();
return obj.validateUser(userId,passwd);
}
public  static String saveProfessor(Professor professor) throws CourseRegException,DBFWException, CourseDAOException, DBConnectionException
{
	AdminDAO obj1=new AdminDAO();
	
	return obj1.saveProfessor(professor);
}
public static String saveCourse(Course c) throws CourseRegException,DBFWException, CourseDAOException, DBConnectionException
{
AdminDAO obj1=new AdminDAO();
	
	return obj1.saveCourse(c);
}
public static String saveStudent(Student s) throws CourseRegException,DBFWException, CourseDAOException, DBConnectionException
{
AdminDAO obj1=new AdminDAO();
	
	return obj1.saveStudent(s);
}
public static List<Professor> getAllProf() throws CourseRegException,DBFWException, CourseDAOException, DBConnectionException
{
AdminDAO obj1=new AdminDAO();
	
	return obj1.getAllProf();
}
public static List<Department> getAllDept() throws CourseRegException,DBFWException, CourseDAOException, DBConnectionException
{
AdminDAO obj1=new AdminDAO();
	
	return obj1.getAllDept();
}
public static List<Course> getAllCourse() throws CourseRegException,DBFWException, CourseDAOException, DBConnectionException
{
	StudentDAO obj2=new StudentDAO();
	return obj2.getAllCourse();
}
public static int saveProfCourses(StudPreference studpref) throws CourseRegException,DBFWException, CourseDAOException, DBConnectionException
{
	StudentDAO obj2=new StudentDAO();
	return obj2.saveCoursePref(studpref);
}
public static List<CoursePreference> getPrefCourse(String studId) throws CourseRegException,DBFWException, CourseDAOException, DBConnectionException
{
	StudentDAO obj2=new StudentDAO();
	return obj2.getPrefCourse(studId);
}
	}


