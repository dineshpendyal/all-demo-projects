package com.nttdata.course.dao;

public class coursedaoexception extends Exception{

	public coursedaoexception(String x,Throwable y)
	{
	super(x,y);
		
	}
	public coursedaoexception(String x)
	{
		super(x);
	}
	

}
