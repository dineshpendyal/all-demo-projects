package com.nttdata;

public class userprofile {

	private studetails name;
	private	address address;
	
	
	public studetails getName() {
		return name;
	}

public void setName(studetails name) {
		this.name = name;
	}

public address getAddress() {
		return address;
	}


public void setAddress(address address) {
		this.address = address;
	}











	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
