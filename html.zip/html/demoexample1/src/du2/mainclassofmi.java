package du2;

public class mainclassofmi {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		multipleinheritance obj=new multipleinheritance();
		obj.read(10, 20);
		obj.calculate(30, 40);
		anotherclass obj2=new anotherclass();
		obj2.calculate(30, 40);
		
		
	}

}
