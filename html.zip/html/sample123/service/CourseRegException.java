package com.nttdata.course.service;

public class CourseRegException extends Exception {

	
public CourseRegException(String message, Throwable cause)
{
	super(message,cause);
	
}
public CourseRegException(String message)
{
	super(message);
}
	

}
