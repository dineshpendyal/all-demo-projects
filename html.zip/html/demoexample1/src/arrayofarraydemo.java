
public class arrayofarraydemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] cartoons=
			{
				{"flinstones","fred","wilma","pebbles","dino"},{"rubbles","barney","betty","bam bam",},
			};
		for(int i=0;i<cartoons.length;i++)
		{
			System.out.println(cartoons[i][0]+":");
		for(int j=1;j<cartoons[i].length;j++)
			System.out.println(cartoons[i][j]+":");

		}
		System.out.println();
	

	}

}
