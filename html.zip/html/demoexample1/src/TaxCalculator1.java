

public class TaxCalculator1 {

		  public SalaryDetails calculateTax(EmployeeJB emp)
		  {
			  float netSalary = (emp.getBasic()+ emp.getDearnessAllowance() + emp.getHouseRentAllowance() - emp.getProvidentFund())*12;
			  double employeeTax;
			  SalaryDetails employeeSalary = new SalaryDetails();
			  if(netSalary < 300000)
			  {
				  employeeSalary.setNetSalary(netSalary);
				  employeeSalary.setTax(0);
		  }
			  else if(netSalary >= 300000 && netSalary < 500000)
			  {
				employeeTax = netSalary * 0.01;
				employeeSalary.setNetSalary(netSalary);
				employeeSalary.setTax(employeeTax);
			  }
			  else if(netSalary >= 500000 && netSalary < 1000000)
			  {
				employeeTax = netSalary * 0.02;
				employeeSalary.setNetSalary(netSalary);
				employeeSalary.setTax(employeeTax);
			  }
			  else 
			  {
				employeeTax = netSalary * 0.03;
				employeeSalary.setNetSalary(netSalary);
				employeeSalary.setTax(employeeTax);
			  }
		  employeeSalary.setEmployeeID(emp.getEmployeeID());
		  return employeeSalary;
	}
}
