package web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import dbcon.DBConnectionException;
import mvc.HttpRequestHandler;
import dao.adminDAO;
import dao.CourseDAOException;
import dao.DAOAppException;
import dao.loginDAO;
import domain.user;
import domain.professor;
import service.courseregexception;

import service.courseregfacade;

public class AddProfessor implements HttpRequestHandler {

	public static Logger log = Logger.getLogger(Login.class);

	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		System.out.println("in handle of add professor");
		String profId = request.getParameter("txtProfId");
		String profName = request.getParameter("txtProfName");
		String dept=request.getParameter("sltDept");
		//adminDAO dao = new adminDAO();
		//adminDAO admin=new adminDAO();
		courseregfacade c=new courseregfacade();
		System.out.println("before professor object of add professor");
		professor p=new professor(profId,profName, dept); 
		System.out.println("before professor object of add professor");
		try {
        	System.out.println("in try of add professor");
			String profIdsaved=c.saveProfessor(p);
			if (!profIdsaved.equals("")) 
			{
				RequestDispatcher dispatcher = request.getRequestDispatcher("AddProfessorSuccess.jsp");
				request.setAttribute("Name", profId);
				//request.getAttribute("Name");
				dispatcher.forward(request, response);

			} 
			else 
			
			{
			RequestDispatcher dispatcher = request.getRequestDispatcher("Login.jsp");
				request.setAttribute("Err","username or password is incorrect");
				dispatcher.forward(request, response);
			}				
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (courseregexception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CourseDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    //String id=admin.saveProfessor(professor);
	   //return id;
		
		}
	}