package inheritanceexamples;

import java.util.Scanner;

class exofarrays
{
int i;
int[] marks;
double[] marks1;
float[] marks2;
String[] marks3;
Scanner sc=new Scanner(System.in);

void read(int x)
{
	marks[i]=x;

}


void display(int[] x)
{
	
	for(int i=0;i<x.length;i++)
	{
		System.out.println(x[i]);
		
	}

}

void display(float[] x)
{
	
	for(int i=0;i<x.length;i++)
	{
		System.out.println(x[i]);
		
	}

}
void display(double[] x)
{
	
	for(int i=0;i<x.length;i++)
	{
		System.out.println(x[i]);
		
	}

}
void display(String[] x)
{
	
	for(int i=0;i<x.length;i++)
	{
		System.out.println(x[i]);
		
	}

}


}



public class manyarrays {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

exofarrays ob=new exofarrays();
ob.read(10);


	
	
	}

}
