package com.nttdata.course.dao;



import java.sql.ResultSet;
import java.sql.SQLException;
//import com.nttdata.dbfw.ResultMapper;
import com.ntt.dbfw.*;
import com.nttdata.course.dao.userdao;
import com.nttdata.course.domain.user;
import com.ntt.*;

	public class SQLMapper {
		
//static final String a="select userid,username,password,roleid from userdetails where userid=? and password=?";

		public static final String VALIDATE_USER="select userid,username,password,roleid from userdetails where userid=? and password=?";
		public static final ResultMapper MAP_Student = new ResultMapper(){
			public Object mapRow(ResultSet rs) throws SQLException{
				user u=new user(rs.getString("userid"),rs.getString("username"),rs.getString("password"),rs.getString("roleid"));
				return u;
			}
		};
	}
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	




