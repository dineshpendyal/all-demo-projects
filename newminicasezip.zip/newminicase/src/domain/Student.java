package domain;

import java.util.Date;

public class Student {
private String StudId;
private String StudentName;
private String Address;
private Date Dob;
private String Degree;
public Student(String studId, String studentName, String address, Date dob, String degree) 
{
	super();
	StudId = studId;
	StudentName = studentName;
	Address = address;
	Dob = dob;
	Degree = degree;
}

public Student(String studid)
{
StudId=studid;	

}


public Student() {
	// TODO Auto-generated constructor stub
}

public String getStudId() {
	return StudId;
}
public void setStudId(String studId) {
	StudId = studId;
}
public String getStudentName() {
	return StudentName;
}
public void setStudentName(String studentName) {
	StudentName = studentName;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public Date getDob() {
	return Dob;
}
public void setDob(Date dob) {
	Dob = dob;
}
public String getDegree() {
	return Degree;
}
public void setDegree(String degree) {
	Degree = degree;
}


}
