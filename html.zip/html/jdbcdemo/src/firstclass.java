import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Properties;


public class firstclass {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Properties pr=new Properties();
		try
		{
			FileInputStream in=new FileInputStream("jdbcconnectionfile.properties");
			pr.load(in);
			String driver =pr.getProperty("driver");
			String conurl =pr.getProperty("url");
			String user =pr.getProperty("user");
			String pass =pr.getProperty("password");
			//Class.forName(pr.getProperty("driver"));
			Class.forName(driver);
			Connection con=DriverManager.getConnection(conurl,user,pass);
			//Statement stmt=con.createStatement();
			String str="select * from nttjdbc where id>?";
			PreparedStatement pstmt=con.prepareStatement(str);
			
			//passingconnectionobjectex.display(con,pstmt,str);
			secondclass.display(con, pstmt, str);
		}
		
		
		catch(Exception e){
			
		System.out.println(e);
		}
		}

}
