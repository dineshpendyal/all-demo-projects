package com.ntt.driver;

import java.util.List;
import java.util.Scanner;

import com.ntt.dbfw.DBFWException;
import com.nttdata.course.dao.coursedaoexception;
import com.nttdata.course.dao.userdao;
import com.nttdata.course.domain.user;
import com.nttdata.course.service.courseregfacade;

public class courseregisterdriver {

	/**
	 * @param args
	 * @throws coursedaoexception 
	 * @throws  
	 */
	public static void main(String[] args) throws coursedaoexception {
		
		List clist=null;
	//	int ch=0;
		int status=0;
		String uid;
		String pwd;
		Scanner sc=new Scanner(System.in);
	
		do{
			System.out.println("welcome!enter the username");
			uid=sc.next();
			System.out.println("enter the password");
	        pwd=sc.next();
	        //courseregfacade.validate
			//String x=userdao.validateuser(uid, pwd);
			courseregfacade obj=new courseregfacade();
			

		user x=null;
		x=obj.validateuser(uid, pwd);
		System.out.println(x);
	
		System.out.println("hi");
		System.out.println(x.getRoleid());
	   String k=x.getRoleid();
		
	if(k=="1")
			{
				System.out.println("you are admin");
				int ch;
				System.out.println("select your choice");
				System.out.println("enter 1 for adding professor");
				System.out.println("enetr 2 for adding course");
				System.out.println("enter 3 for adding a student");
				ch=sc.nextInt();
				switch (ch) {
				case 1:
				String profname;
				String deptid;
				System.out.println("enter professor name");
				profname=sc.next();
				System.out.println("enter deptid");
				deptid=sc.next();
				
				
				
				break;

				default:
					break;
				}

				
			}
			else if(k=="2")
			{
			System.out.println("you are a student");	
			}
			else
			{
				System.out.println("invalid option neither admin nor student");
				
			}
				
		}
		while(!(status==0));
		System.out.println("\n\n Thank You \n\n");
		
		
	}

}
