

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class finalpurchasetosite
 */
@WebServlet("/finalpurchasetosite")
public class finalpurchasetosite extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public finalpurchasetosite() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		String price=request.getParameter("price");
        int x=Integer.parseInt(price);	
        HttpSession session=request.getSession();
		String n=(String)session.getAttribute("uname");
	
		System.out.println(n);
        
        try
		{
			//Locale.setDefault(Locale.ENGLISH);
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","TRDBNTT","TRDBNTT");
			
			PrintWriter pw=response.getWriter();
			Statement stmt=con.createStatement();
	 		ResultSet rs=stmt.executeQuery("select opbal from usercarddetails where username='"+n+"'");
	      // String sql = "select opbal from usercarddetails where username='thiru' and password='thiru123'";
           //System.out.println(sql);
		
	       //PreparedStatement pstmt=con.prepareStatement(sql);

	       // ResultSet rs=pstmt.executeQuery();
//	        int k=rs.getInt(1);
  //   int z=k-x;
//	        System.out.println(z);
	 		
	 		
	 		
	 		
//	       
	        
	 		while(rs.next())
			{
			if(rs.getInt(1)<x)
			{
				pw.println("Insufficient bal");
			}
			else
			{	
				int z=rs.getInt(1)-x;
				stmt.executeUpdate("update usercarddetails set opbal='"+z+"'where username='"+n+"'");
				pw.println("Thanks for buying image");
			//	response.sendRedirect("hometosite.html");
				
			}
			}
//	 		while(rs.next())
//	        {
//	        if(rs.getInt(1)<x)
//	        {
//	        	System.out.println("insufficient balance");
//	        	return;
//	        }
//	       
//	        else
//	        {
//	          System.out.println("item bought");
////	        	 String sql1 = "update usercarddetails set opbal='z'where username='thiru' and password='thiru'123'";
////	        	 PreparedStatement pstmt1=con.prepareStatement(sql1);
////	        	 ResultSet rs1=pstmt1.executeQuery();
//	        	 //System.out.println(rs1.getString("opbal"));
//	        	 break;
//	        	 
//	        }
//	  
//	        }
		}
		catch(Exception e)
		{
			
			System.out.println(e);
			
		}
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
