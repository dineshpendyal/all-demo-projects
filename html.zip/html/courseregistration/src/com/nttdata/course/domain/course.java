package com.nttdata.course.domain;

public class course {

	private String courseid;
	private String coursename;
	private String profid;
	public String getCourseid() {
		return courseid;
	}
	public void setCourseid(String courseid) {
		this.courseid = courseid;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public String getProfid() {
		return profid;
	}
	public void setProfid(String profid) {
		this.profid = profid;
	}
	
	
	
	
//public course(String x,String y,String z)
//{
//	this.courseid=x;
//	this.coursename=y;
//	this.profid=z;
//	
//	
//}
	
}
