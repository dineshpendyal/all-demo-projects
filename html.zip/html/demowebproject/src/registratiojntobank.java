

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class registratiojntobank
 */
@WebServlet("/registratiojntobank")
public class registratiojntobank extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public registratiojntobank() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		String str1=request.getParameter("userreg");
		String str2=request.getParameter("passreg");
		String str3=request.getParameter("num");
		String str4=request.getParameter("mail");
		String str5=request.getParameter("Gender");
		String str6=request.getParameter("aadhar");
		String str7=request.getParameter("pan");
		try
		{
			//Locale.setDefault(Locale.ENGLISH);
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","TRDBNTT","TRDBNTT");
			
			
	        String sql = "insert into servletex values('"+str1+"','"+str2+"','"+str3+"','"+str4+"','"+str5+"','"+str6+"','"+str7+"')";

	        System.out.println(sql);
			
	        PreparedStatement pstmt=con.prepareStatement(sql);
	        ResultSet rs=pstmt.executeQuery();
	        if(rs.next())
	        {
	        	
	        	System.out.println("succesfully registered");
	        	response.sendRedirect("logindemo.html");
	        	
	        }
	        else
	        {
	        	
	        	System.out.println("failed to register please try again");
	        }
	
		}
		
		
		catch(Exception e)
		{
			
			System.out.println(e);
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
