import junit.framework.TestCase;


public class arithmeticTest extends TestCase {

	public void testAdd() {
		//fail("Not yet implemented");
	
	arithmetic obj=new arithmetic();
	int expected=30;
	int actual=obj.add(10,20);
	assertTrue(expected==actual);
	
	}

	public void testSub() {
		fail("Not yet implemented");
	}

}
