package web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import dbcon.DBConnectionException;
import dbfw.DBFWException;
import mvc.HttpRequestHandler;
import dao.adminDAO;
import dao.CourseDAOException;
import dao.DAOAppException;
import dao.loginDAO;
import domain.user;
import domain.professor;
import service.courseregexception;
import service.courseregfacade;
import domain.course;

public class ViewAllCourses implements HttpRequestHandler {

	public static Logger log = Logger.getLogger(Login.class);

	public void handle(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		 List courses; 
		 courseregfacade course1=new courseregfacade();
	    try {
			courses =course1.getAllCourse();
			/*Iterator itr=courses.iterator();
			while(itr.hasNext())
			{
				Course c=(Course)itr.next();*/
			RequestDispatcher dispatcher = request.getRequestDispatcher("ViewAllCourses.jsp");
			request.setAttribute("list", courses);
			dispatcher.forward(request, response);
				/*System.out.print(c.getCourseId()+"  ");
				System.out.print(c.getCourseName()+" ");
				System.out.print(c.getProfId()+"   ");
				System.out.println();
	                            		*/	
			
	        
		} catch (DBFWException | DBConnectionException | courseregexception
				| CourseDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*Iterator itr=courses.iterator();
		while(itr.hasNext())
		{
			Course c=(Course)itr.next();
			System.out.print(c.getCourseId()+"  ");
			System.out.print(c.getCourseName()+" ");
			System.out.print(c.getProfId()+"   ");
			System.out.println();
                            			
		
        }*/
		
			
		
		}
	}
