package com.nttdata.collectionexamples;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.Buffer;

public class readtextfromstdinput {

	private static void process(String str)
	{
		System.out.println("processing"+str);
		
		
	}
	private static void doreadfromstdin() {
		
		try
		{
			BufferedReader inStream=new BufferedReader(new InputStreamReader(System.in));
            String inLine="";
	while(!inLine.equalsIgnoreCase("exit")&&!inLine.equalsIgnoreCase("quit"))
	{
		System.out.println("prompt>");
		inLine=inStream.readLine();
		process(inLine);
		
	}
	
	}
	
	catch(Exception e)
	{
		System.out.println("IO exception"+e);
		
	}
}	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		readtextfromstdinput dr=new readtextfromstdinput();
		dr.doreadfromstdin();
	
	
	}

}
