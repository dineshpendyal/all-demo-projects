
//import package.abstarctclass.class1;
import package abstarctclass.class1;


public class class2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		class1.display();
		
		
	}

}
