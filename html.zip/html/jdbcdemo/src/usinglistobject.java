import java.util.List;
import java.io.ObjectInputStream.GetField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;





class nttjdbc
{
int id;
int sal;
String name;
String location;
}



public class usinglistobject {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

try{
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521"," TRDB12","TRDB12");
	Statement stmt=con.createStatement();
	ResultSet rs=stmt.executeQuery("select *from empdetails ");
	
//	ArrayList l1=new ArrayList();
	
	//ArrayList l1=new ArrayList();
//	List l1=new ArrayList();
	List l1=new ArrayList();
	//List l1=new ArrayList();
	while(rs.next())
	{
		nttjdbc e=new nttjdbc();
		e.id=rs.getInt(1);
		e.id=rs.getInt(2);
		e.name=rs.getString(3);
		e.location=rs.getString(4);
		l1.add(e);
		
	}
	
	Iterator itr=l1.iterator();
	while(itr.hasNext())
	{
		nttjdbc e=new nttjdbc();
		e=(nttjdbc)itr.next();
		System.out.println(e.id);
		System.out.println(e.name);
		
		
	}
	
	
	
}
catch(Exception e){
	 System.out.println(e);
	
}	
	
	
	
	}

}
