import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;


public class secondclass {

	/**
	 * @param args
	 */
	
	static void display(Connection con, PreparedStatement pstmt,String str)
	{
	try
	{	
		//pstmt.setInt(1, 100);
		System.out.println(str);
		pstmt.setInt(1,100);
		ResultSet rs=pstmt.executeQuery();
		
		//pstmt.executeQuery(str);
		while(rs.next())
		{
		
		//pstmt.executeUpdate();
			
		System.out.println(rs.getString(1));	
		
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
		//System.out.println(e);
	}	
	}
	
	
	}
