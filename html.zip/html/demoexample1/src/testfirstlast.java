import java.util.Scanner;
public class testfirstlast {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=123457;
		int count=0;
		int[] a=new int[7];
		int i=0;
		while(num>=0)
		{
			
			a[i]=num%10;
			count+=1;
			i++;
			num=num/10;
			
		}
		System.out.println("the  first digit of the num is:"+ a[5]);
		System.out.println("the last digit of the num is:"+ a[0]);
		
		}
		
 
	}


