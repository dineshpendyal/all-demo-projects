package nestedclasses;

import java.util.Scanner;

final class ipl extends abcd
{
String[] teamnames;
String[] captains;
void display()
{
	}

}
class abcd 
{
	}
interface inter123
{
void read();	
}

public class finalclassexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
inter123 i1=new inter123()
{
public void read()
{
	Scanner sc=new Scanner(System.in);
	int a;
a=sc.nextInt();
System.out.println(a);
}

	};
	i1.read();

}}
