package inheritanceexamples;

import java.util.Scanner;

public class employee1 {
public int eid;
public String name;
public employee1()
{
eid=100;
name="noel";
}
void read()
{
	Scanner sc=new Scanner(System.in);
	eid=sc.nextInt();
	name=sc.next();
	}

void display()
{
	System.out.println(eid);
	System.out.println(name);
}
class manager1 extends employee1
{
	int deptid;
	int noofemployees;
	}
//public class employee extends employee1
{
	}
	/**
	 * @param args
	 */
	
class employee extends employee1
{
	manager1 m1=new manager1();
	System.out.println(m1.display(););
public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
}