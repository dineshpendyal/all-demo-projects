package reflectionexamples;
public class reflectionnameexample {

//	public class kid
//	{
//		String name;
//		int age;
//		
//	}
	
	static void printname(Object o)
	{
		Class c=o.getClass();
		String str=c.getName();
		System.out.println("object belongs to "+str+" class");
		
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		kid k=new kid();
		printname(k);
	    String s=new String();
	    printname(s);
	}

}
