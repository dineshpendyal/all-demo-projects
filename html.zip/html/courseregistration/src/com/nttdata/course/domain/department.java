package com.nttdata.course.domain;

public class department {

	private String deptid;
	private String deptname;
	public String getDeptid() {
		return deptid;
	}
	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	
//	public department(String x,String y)
//	{
//		this.deptid=x;
//		this.deptname=y;
//		
//	}
}
