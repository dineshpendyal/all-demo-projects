package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import dbcon.ConnectionHolder;
import dbcon.DBConnectionException;
import dbfw.DBFWException;
import dbfw.DBHelper;
import dbfw.ParamMapper;
import domain.Course;
import domain.CoursePreference;
import domain.StudPreference;

public class StudentDAO {

	
private static final String MAParamMapper = null;
public List<Course> getAllCourse() throws DBFWException, CourseDAOException, DBConnectionException
{
	List Course=null;
	ConnectionHolder ch=null;
	Connection con=null;
	

	
	try {
		ch=ConnectionHolder.getInstance();
		con=ch.getConnection();
		
		
		Course= DBHelper.executeSelect(con,SQLMapper.FETCHCOURSE,SQLMapper.COURSEMAPPER);
				
		
	} catch (DBConnectionException e) {
		throw new DBConnectionException("Unable to get all courses");
	
	}
	finally {

		try {

			if (con != null)
				con.close();

		} catch (SQLException e) {
		}
	}
	
	
	return Course;
	
}

public int saveCoursePref(final StudPreference studPref) throws DBFWException, CourseDAOException, DBConnectionException
{
	ConnectionHolder ch=null;
	Connection con=null;
	int  result=0;
	List count=null;
	int noofprefcourses=studPref.getprefCourse().size();
	
	
		
	               ParamMapper SAVEPREFERENCE=new ParamMapper()
			        {
				        public void mapParam(PreparedStatement preStmt)
						throws SQLException 
				        {
				        	preStmt.setString(1, studPref.getStudId());
				        	
				        	preStmt.setString(2,((CoursePreference) studPref.getprefCourse().get(0)).getCourseId());	
				        	preStmt.setString(3,((CoursePreference) studPref.getprefCourse().get(0)).getPreference());	
						}
				
			          };
//			          ParamMapper SAVEPREFERENCE1=new ParamMapper()
//				        {
//					        public void mapParam(PreparedStatement preStmt)
//							throws SQLException 
//					        {
//					        	preStmt.setString(1, studPref.getStudId());
//					        	preStmt.setString(2, "p");
//					        		
//							}
//					
//				          };
			          try {
			        	  ch=ConnectionHolder.getInstance();
			        	  con=ch.getConnection();
			        	  int pre=DBHelper.executeUpdate(con,SQLMapper.SAVEPREFERENCE,SAVEPREFERENCE );  
			        	  System.out.println(pre);
			        	  
			            //count = DBHelper.executeSelect(con,SQLMapper.FETCHSTUD_COURSE,SQLMapper.NUMBEROFPREFCOMAPPER,SAVEPREFERENCE1);
			        	count = DBHelper.executeSelect(con,SQLMapper.FETCHSTUD_COURSE,SQLMapper.NUMBERMAPPER);
			            Iterator itr=count.iterator();
			            result=(Integer) itr.next();
			    	   
			            //  result=(int) itr.next();
			          }
			          
		catch (DBFWException e) {
			
			e.printStackTrace();
			
		}
		catch (DBConnectionException e) {
			
			e.printStackTrace();
		}
	//}
			          
		
		//return noofprefcourses;
			          return result;
	
}


public List<CoursePreference> getPrefCourse(String studId) throws DBFWException, CourseDAOException, DBConnectionException
{
	List Course=null;
	
	ConnectionHolder ch=null;
	Connection con=null;
	
	try {
		ch=ConnectionHolder.getInstance();
		con=ch.getConnection();
		
		Course=DBHelper.executeSelect(con,SQLMapper.FETCHPREFERREDCOURSE,SQLMapper.COURSEMAPPER2);
		return Course;
	   
	} 
	catch (DBConnectionException e)
	{
		throw new DBConnectionException("Unable to connect");
	}
	finally {

		try {

			if (con != null)
				con.close();

		}
		catch (SQLException e) 
		{
		System.out.println(e);
		}
	}

	
	
}
}



