package service;

public class courseregexception extends Throwable {
public courseregexception(String message,Throwable cause)
{
	super(message,cause);
}
public courseregexception(String message)
{
	super(message);
}
}
