
public class myexception extends Exception{

 
	public myexception()
	{
		System.out.println("from myexception divided by zero");
	}
	
	
	
	/**
	 * @param args
	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}
