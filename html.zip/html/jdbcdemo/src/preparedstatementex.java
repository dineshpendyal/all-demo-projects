import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;


public class preparedstatementex {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521"," TRDB12","TRDB12");
		//Statement stmt=con.createStatement();
		PreparedStatement stmt=con.prepareStatement("insert into nttjdbc values(?,?,?,?)");
		stmt.setInt(1, 1000);
		stmt.setInt(2, 2000);
		stmt.setString(3, "name3");
		stmt.setString(4, "bangalore");
		stmt.executeQuery();
		
		
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	
	}

}
