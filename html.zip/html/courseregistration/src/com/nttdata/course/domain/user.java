package com.nttdata.course.domain;

public class user {

	private String userid;
	private String username;
	private String password;
	private String roleid;
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRoleid() {
		return roleid;
	}
	public void setRoleid(String roleid) {
		this.roleid = roleid;
	}
	
	
	public user()
{
		
		System.out.println("this is default constructor for user class");
		
	}
	
	
	public user(String a,String b,String c,String d)
	{
		
		this.userid=a;
		this.username=b;
	 this.password=c;
		this.roleid=d;
				
		
	}
	
	
	
	

}
