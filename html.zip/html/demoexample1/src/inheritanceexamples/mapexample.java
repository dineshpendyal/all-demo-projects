package inheritanceexamples;

import java.util.HashMap;
import java.util.Map;

public class mapexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<Integer,String> m1=new HashMap<Integer, String>();
		
		//Map m1=new HashMap();
		Map m2=new HashMap();
		
		m1.put(10, "student10");
		m1.put(20, "student20");
		m2.put(100, "student100");
		m2.put(200, "student200");
		m1.putAll(m2);
		System.out.println(m1.containsKey(10));
		System.out.println(m1.containsKey(100));
		
		for(Map.Entry m:m1.entrySet())
		{
			System.out.println(m.getKey()+" "+m.getValue());
			
		}
		m1.remove("student10");
		m1.remove(2000);
		
		
		for(Map.Entry m:m1.entrySet())
		{
			System.out.println(m.getKey()+" "+m.getValue());
			
		}
		
	
		
	}

}
