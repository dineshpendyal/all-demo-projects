package inheritanceexamples;

class employee{
	
	int age;
	int bonus;
	public employee(int x,int y)
	{
		age=x;
		bonus=y;
	}
	
}
class manager11
{
	int salary;
	employee e;
	
	public manager11(int x,employee y){
		
		salary=x;
		e=y;
	}
	void display()
	{
	System.out.println(e.age);	
		
		
	}

}




public class aggregationexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	employee e1=new employee(20,10000);
	manager11 m=new manager11(10,e1);
	System.out.println(m.salary);
	System.out.println(m.e.age);
	
	}

}
