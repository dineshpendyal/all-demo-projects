package reflectionexamples;

public class newinstanceexample {

	/**
	 * @param args
	 */
	static Object createObject(String str)
	{
		Object o=null;
		try{
		//	Object o=null;	
		
		Class ss=Class.forName(str);
		
		o=ss.newInstance();
		}
		catch(ClassNotFoundException c)
		{
			System.out.println(c);
			
		}
		
		catch(IllegalAccessException c)
		{
			System.out.println(c);
			
		}
		catch(InstantiationException c)
		{
			System.out.println(c);
			
		}
		return o;
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="reflectionexamples.kid";
kid k=(kid)createObject(str);
k.display(10, "thiru");
k.read(20);
	
	}

//	private static kid createObject(String str) {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
