package du2;

import abstarctclass.class1;
//import abstarctclass.*;
//import static java.lang.System.*;



public class class2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		class1.display();
		
		
	}

}
