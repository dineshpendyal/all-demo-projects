package domain;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import dbcon.DBConnectionException;
import dbfw.DBFWException;
import dao.CourseDAOException;
import dao.studentDAO;


public class studentpreference {
private String studId;
private List<coursepreference> prefCourse;

public String getStudId() {
	return studId;
}
public void setStudId(String studId) {
	this.studId = studId;
}
public List<coursepreference> getPrefCourse() {
	return prefCourse;
}
public void setPrefCourse(List<coursepreference> prefCourse) {
	this.prefCourse = prefCourse;
}




public studentpreference() {
	super();
}
public studentpreference(String studId, List<coursepreference> prefCourse) {
	this.studId = studId;
	this.prefCourse = prefCourse;
}



public int addPref(studentpreference studPref) throws CourseDAOException, DBConnectionException, DBFWException{
	java.util.List<coursepreference>lis=new ArrayList<coursepreference>();
	int primarycount=0;
	int secondarycount=0;
	studentDAO sd=new studentDAO();
	lis=sd.getPrefCourses(studPref.getStudId());
	Iterator<coursepreference> it=lis.iterator();
	coursepreference cp=new coursepreference();
	
	while(it.hasNext()){
		cp=(coursepreference)it.next();
		if(cp.getPrefCourse().equalsIgnoreCase("pri")){
			primarycount++;
		}
		if(cp.getPrefCourse().equalsIgnoreCase("sec")){
			secondarycount++;
		}
	}
	
	if(primarycount<4 && studPref.getPrefCourse().get(0).getPrefCourse().equalsIgnoreCase("pri"))
	 {
		 return 1;
	 }
	 if(secondarycount<2 && studPref.getPrefCourse().get(0).getPrefCourse().equalsIgnoreCase("sec"))
	 {
		 return 2;
	 }
	return 0;
}
}
	
	
	
	
	

