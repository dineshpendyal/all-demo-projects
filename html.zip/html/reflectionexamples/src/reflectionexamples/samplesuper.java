package reflectionexamples;
public class samplesuper {

	/**
	 * @param args
	 */
	
//	public void printsuper(Object o)
//	{
//		Class c=o.getClass();
//	}
	static void printsuper(Object o)
	{
		Class subClass=o.getClass();
		Class superClass=subClass.getSuperclass();
		 while(superClass!=null)
		 {
			 String str=superClass.getName();
			 System.out.println(str);
			 subClass=superClass;
			 superClass=subClass.getSuperclass();
			 
		 }
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		kid k=new kid();
		printsuper(k);
		
	}

}
