package dbcon;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;

public class ConnectionHolder {

	private static ConnectionHolder connectionHolderInstance = null;

	private DataSource ds = null;

	private ConnectionHolder() {
	}

//	private void initAppDatasource() throws DBConnectionException {
//		System.out.println("in connection");
//
//		try {
//
//			BasicDataSource bds = new BasicDataSource();
//			System.out.println("in connection1");
//			Properties ps = new Properties();
//			System.out.println("in connection2");
//			 FileReader reader=new FileReader("jdbcds.properties");  
//			 System.out.println("in connection3");
//			ps.load(reader);
//			
//			//ps.load(new FileInputStream("jdbcds.properties"));
//			System.out.println("in connection3");
//			//ps.load(new FileInputStream("C:\\091322\\Induction\\FrontControllerApp\\src\\jdbcds.properties"));
//			String uid = ps.getProperty("uid");
//			String pwd = ps.getProperty("pwd");
//			String URL = ps.getProperty("url");
//			String driverclazz = ps.getProperty("driver");
//			System.out.println("1");
//			bds.setUrl(URL);
//			bds.setDriverClassName(driverclazz);
//			bds.setUsername(uid);
//			bds.setPassword(pwd);
//			System.out.println("initapp2");
//			this.ds = bds;
//			System.out.println("initapp3");
//		} catch (FileNotFoundException e) {
//
//			throw new DBConnectionException(
//					"Unable to get connection Data to the database", e);
//
//		} catch (IOException e) {
//
//			throw new DBConnectionException(
//					"Unable to get connection Data to the database", e);
//		}
//	}

	// Used during web application instead of the above method
	private void initAppserverDataSource() throws DBConnectionException {
		Context initContext;

		try {
			initContext = new InitialContext();
			Context envContext = (Context) initContext.lookup("java:/comp/env");
			ds = (DataSource) envContext.lookup("jdbc/MyDB");
			System.out.println(ds.toString());
		} catch (NamingException e) {
			e.printStackTrace();
			throw new DBConnectionException("Unable to get datasource", e);

		}
	}


	public static ConnectionHolder getInstance() throws DBConnectionException {

		//	happens only once
		synchronized (ConnectionHolder.class) {

			// use reflection to synchronize as we have no object
			if (connectionHolderInstance == null) {

				connectionHolderInstance = new ConnectionHolder();

				// Replace this line for Web Application
				connectionHolderInstance.initAppserverDataSource();
			}
		}
		return connectionHolderInstance;
	}

	public Connection getConnection() throws DBConnectionException {

		try {
			
			return ds.getConnection();
		} catch (SQLException e) {
			e.printStackTrace();
			throw new DBConnectionException("Unable to obtain a connection", e);
		}
	}

	public void dispose() throws DBConnectionException {

		BasicDataSource bds = (BasicDataSource) ds;
		try {

			bds.close();
		} catch (SQLException e) {

			throw new DBConnectionException("Unable to close the connection", e);
		}
	}
}
