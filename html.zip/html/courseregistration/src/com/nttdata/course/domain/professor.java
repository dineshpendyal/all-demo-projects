package com.nttdata.course.domain;

public class professor {

	private String profid;
	private String profname;
	private String deptid;
	public String getProfid() {
		return profid;
	}
	public void setProfid(String profid) {
		this.profid = profid;
	}
	public String getProfname() {
		return profname;
	}
	public void setProfname(String profname) {
		this.profname = profname;
	}
	public String getDeptid() {
		return deptid;
	}
	public void setDeptid(String deptid) {
		this.deptid = deptid;
	}
	
//	public professor(String x,String y,String z)
//	{
//		this.profid=x;
//		this.profname=y;
//		this.deptid=z;
//		
//				
//	}
	
	
	

}
