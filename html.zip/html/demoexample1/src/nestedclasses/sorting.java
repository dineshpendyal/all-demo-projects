package nestedclasses;

import java.util.Arrays;

public class sorting {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] marks={100,80,60,50};
System.out.println();
Arrays.sort(marks);
for(int i=0;i<marks.length;i++)
{
	System.out.println(marks[i]+"");
}
	
	}

}
