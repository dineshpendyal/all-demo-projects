package dao;

public class DAOAppException extends Exception {

	public DAOAppException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DAOAppException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public DAOAppException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
