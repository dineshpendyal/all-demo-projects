package com.nttdata.collectionexamples;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;

public class readwritefile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

//File input=new File("C:\Users\trgs262.AMERICAS\Desktop\html\demoexample1\src\inheritanceexamples\fileexample.txt");
File input=new File("fileexample.txt");
File output=new File("output.txt");
try
{
	
	FileInputStream fr=new FileInputStream(input);
	FileOutputStream fw=new FileOutputStream(output);
//FileReader fr=new FileReader(input);
//FileWriter fw=new FileWriter(output);
//char ch=(char)fr.read();
int ch=fr.read();
System.out.println(ch);
//while(fr.read()!=-1)
	
{
	ch=(char) fr.read();
	System.out.println(ch);
}
}
catch(Exception e)
{
System.out.println(e);	
}
	
	}

}
