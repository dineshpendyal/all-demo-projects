
public class objectexample {

public Object example()
{
	String k="hello";
	return k;
	
	
}



}
