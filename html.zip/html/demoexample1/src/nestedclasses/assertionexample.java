package nestedclasses;

import java.util.Scanner;

public class assertionexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("enter your age");
		int value=sc.nextInt();
		assert value>=18:"not valid";
		System.out.println("value is"+value);
		
	}

}
