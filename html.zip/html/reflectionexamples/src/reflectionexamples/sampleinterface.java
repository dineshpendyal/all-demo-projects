package reflectionexamples;

public class sampleinterface {

	/**
	 * @param args
	 */
	
	static void printinterfaces(Object o)
	{
		Class c=o.getClass();
		Class[] theinterfaces=c.getInterfaces();
		for(int i=0;i<theinterfaces.length;i++)
		{
			System.out.println(theinterfaces[i].getName());
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	kid k=new kid();
	printinterfaces(k);
	
	}

}
