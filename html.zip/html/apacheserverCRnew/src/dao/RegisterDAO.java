package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import dbcon.ConnectionHolder;
import dbcon.DBConnectionException;
import dbfw.DBFWException;
import dbfw.DBHelper;
import dbfw.ParamMapper;
import domain.user;

public class RegisterDAO {
	public int registerUser(final user user) throws DAOAppException {
		ConnectionHolder ch = null;
		Connection con = null;
		int res = -1;
		ParamMapper mapper = new ParamMapper() {

			@Override
			public void mapParams(PreparedStatement pStmt) throws SQLException {
				pStmt.setString(1, user.getUserId());
				pStmt.setString(2, user.getUserName());
				pStmt.setString(3, user.getPassword());
				pStmt.setString(4, user.getRoleId());
//				pStmt.setString(5, user.getPassword());
			}
		};

		try {
			ch = ConnectionHolder.getInstance();
			con = ch.getConnection();
			res = DBHelper.executeUpdate(con, SQLmapper.ADD_USER, mapper);

		} catch (DBConnectionException e) {
			throw new DAOAppException(e);
		} catch (DBFWException e) {
			throw new DAOAppException(e);
		}
		return res;
	}

	public boolean validateUser(final int portalId) throws DAOAppException {
		ConnectionHolder ch = null;
		Connection con = null;
		List users = null;

		ParamMapper paramMapper = new ParamMapper() {

			@Override
			public void mapParams(PreparedStatement pStmt) throws SQLException {
				pStmt.setInt(1, portalId);
			}
		};
		try {
			ch = ConnectionHolder.getInstance();
			con = ch.getConnection();
			System.out.println(con);
			users = DBHelper.executeSelect(con, SQLmapper.FETCH_USER,paramMapper, SQLmapper.MAP_USER);

		} catch (DBConnectionException e) {
			System.out.println(e);
			throw new DAOAppException(e);
		} catch (DBFWException e) {
			throw new DAOAppException(e);
		}

		return (users != null && users.size() > 0);

	}
}
