



public class exampleofjar {
	public static void main(String args[])
	{

calc c= new calc();
int k=c.add();
System.out.println(k);
	
	}
}
