package web.handlers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import mvc.HttpRequestHandler;
import dao.DAOAppException;
import dao.loginDAO;
import domain.user;
//import domain.user;

public class Login implements HttpRequestHandler {

	public static Logger log = Logger.getLogger(Login.class);

	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String userid = request.getParameter("userid");
		String password = request.getParameter("password");
		int flag = -1;
		List users = null;
		user user1 = new user();
		loginDAO dao = new loginDAO();
		System.out.println("after login dao");
		try {
			users = dao.validateUser(userid,password);
			System.out.println(users);
			System.out.println("after validate ");
			Iterator<user> i= users.iterator();
			for (Object object : users)
			{	System.out.println("in for");
		
				user user2 = (user) object;
				System.out.println(domain.user.getUserId());
				if (domain.user.getUserId().equals(userid))
				{
				flag = 0;
				break;
				}
			}
			log.info("Flag in login " + flag);
			if (flag == 0) 
			{
						//user1 = dao.validateAUser(userid);
						//log.info(user1);
						//for (Object object : users) {//User user = (User) object;
						String k=user1.getRoleId();	
						System.out.println(k);
						if (k.equalsIgnoreCase("1")) {
								 	System.out.println("in admin");
									RequestDispatcher dispatcher = request.getRequestDispatcher("adminmenu.jsp");
									request.setAttribute("Name", userid);
									dispatcher.forward(request, response);
								
							//}
						}
						else if(k.equalsIgnoreCase("2"))
						{
							RequestDispatcher dispatcher = request.getRequestDispatcher("student.jsp");
							request.setAttribute("Name", userid);
							dispatcher.forward(request, response);
							
							
						}
						else 
						{
							
							RequestDispatcher dispatcher = request.getRequestDispatcher("Login.jsp");
							request.setAttribute("Err","username or password is incorrect");
							dispatcher.forward(request, response);
						}
			
			}
				
				
			else
			{
				System.out.println("please try again something is wrong");
			}
		
		} catch (DAOAppException e) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
			request.setAttribute("Err", e.getMessage());
			dispatcher.forward(request, response);

		}

	}
}




//log.info(users);

//Iterator itr=users.iterator();
//Iterator itr=users.iterator();

//while(itr.hasNext())
//{
//	System.out.println("in while");
//	//System.out.println(itr.next());
//	 //user1=(user)itr.next();
//
//	user1=(user)itr.next(); 
//	System.out.println("after itr next");
//	System.out.println(user1.getUserId());
//	 if(user1.getUserId().equals(userid))
//	{
//		System.out.println("in if SETTING FLAG");
//		 flag = 0;
//		break;
//	}
		//return  user1;

	


//if (user.getUserId().equals(userid))
	//{
	//flag = 0;
	//break;
//		}









//for (Object object : users)
//{	System.out.println("in for");
//	user user = (user) object;
//	System.out.println(user.getUserId());
//	if (user.getUserId().equals(userid))
//	{
//	flag = 0;
//	break;
//	}
//}


