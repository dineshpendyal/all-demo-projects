package com.nttdata.course.dao;

import java.util.List;

import com.nttdata.course.domain.course;
import com.nttdata.course.domain.department;
import com.nttdata.course.domain.professor;
import com.nttdata.course.domain.student;

public class admindao {

public String saveprofessor(final professor prof)
{
	//saveprofessor(prof);
	return null;//this null is string
//insert into professor table is left	

}
public String savecourse(course c) throws coursedaoexception
{
	//savecourse(c);
	//insert into course details is left and it returns courseid
	return null;//this null is string
	
}
	
public String savestudent(student s) throws coursedaoexception
{
	//savestudent(s);
	//insert student details into student table and return studid
	return null;
	
}
public List<department> getalldept() throws coursedaoexception
{
	//getalldept();
	return null;
//sql query to select all departments from dept table and return deptlist
	
}

public List<professor> getallprof() throws coursedaoexception
{
	//getallprof();
	return null;
//create sql query to select all professors from professor table and return the professor list	
}


}
