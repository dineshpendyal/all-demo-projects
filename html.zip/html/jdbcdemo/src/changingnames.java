import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class changingnames {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521"," TRDB12","TRDB12");
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select *from empdetails ");
		while(rs.next())
		{
			if(rs.getInt(1)%2==0)
			{
				stmt.executeUpdate("update empdetails set name='john'");
			}
			else
			{
			stmt.executeUpdate("update empdetails set name='abraham'");
			}
			}
			
		}

		
		
	  
	catch(Exception e)
	{
		
	System.out.println(e);	
	}
}}


