package du2;

public class aggregatex {

	     
		 //static aggex ag;
	     aggex ag;
		public double pi=3.14;  
		    
		 

	 public static void main(String args[]){  
	  aggex obj=new aggex();  
	  double result=obj.area(5);  
	  System.out.println(result);
	  result=ag.area(5);
	 
}
}