import java.util.Scanner;
class student
{
	int[] marks=new int[6];
			}
public class studentexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
student[] std=new student[5];
int sum=0;
int avg;
Scanner sc=new Scanner(System.in);
for(int i=0;i<std.length;i++)
{
	std[i]=new student();
	System.out.println("enter marks of"+(i+1)+"th student");
	for(int j=0;j<std[i].marks.length;j++)
	{
		std[i].marks[j]=sc.nextInt();
		sum+=std[i].marks[j];
	}
	
	
	avg=sum/std.length*6;
	System.out.println("class average"+avg);

}
	}}
