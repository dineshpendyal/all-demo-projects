import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Scanner;


public class example1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521"," TRDB12","TRDB12");
		Statement stmt=con.createStatement();
for(int i=1;i<=5;i++)
{
System.out.println("enter the name deatils id is auto");	
Scanner sc=new Scanner(System.in);
String str=sc.next();
int x=stmt.executeUpdate("insert into empdetails values("+i+",'"+str+"')");

}

}
catch(Exception e)
{
	System.out.println(e);
}
}
	
	}


