

public class TaxCalculatorMain {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        TaxCalculator calc = new TaxCalculator();
        EmployeeJB emp1 = new EmployeeJB();
        emp1.setEmployeeID(3214);
        emp1.setEmployeeName("James");
        emp1.setBasic(20000);
        emp1.setDearnessAllowance(6000);
        emp1.setHouseRentAllowance(4800);
        emp1.setProvidentFund(2400);
        SalaryDetails details = calc.calculateTax(emp1);
        System.out.println("Employee Name "+emp1.getEmployeeName());
        System.out.println("Employee ID "+emp1.getEmployeeID());
        System.out.println("Net Salary "+details.getNetSalary());
        System.out.println("Tax "+details.getTax());
	}

}
