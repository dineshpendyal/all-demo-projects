
public class operatorsexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		int c=a&b;
		if(a>=10&&b>15)
		   {
			System.out.println("and is true");
		   }
		else{
			System.out.println("and is false");
		    }
	
	System.out.println("value of c" +c);
	}
}
