package inheritanceexamples;

public class driverexample {

	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		interestrate i=new sbiclass();
		int x=i.giveinterest();
		System.out.println(x);
		i=new unionclass();
		int k=i.giveinterest();
		
	//	x=i.giveinterest(10000);
		System.out.println(k);
	}

}
