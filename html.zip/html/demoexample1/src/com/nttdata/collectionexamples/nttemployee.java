package com.nttdata.collectionexamples;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
 class thiru{
	 
	 int age;
	 int salary;
	 String Worklocation;

	 public thiru(int x,int y,String z)
	 {
		 age=x;
		 salary=y;
		 Worklocation=z;
		 
	 }
 
 }



public class nttemployee {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
List l11=new ArrayList();
thiru t1=new thiru(10,10000,"thiru");
thiru t2=new thiru(20,20000,"pati");
thiru t3=new thiru(30,30000,"rao");
thiru t4=new thiru(40,40000,"rao2");
l11.add(t1);
l11.add(t2);
l11.add(t3);
l11.add(t4);
Iterator itr=l11.iterator();
while (itr.hasNext()) {

	thiru t=(thiru)itr.next();
	System.out.println(t.age+" "+t.salary+" "+t.Worklocation);
	
	//System.out.println(itr.next());
	//type type = (type) itr.nextElement();
	
}

		
		
		
	}

}
