
public class numbers {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int num=12345;
		int x;
		int digitsum=0;
		int count=0;
		while(num!=0)
		{
			x=num%10;
			digitsum=digitsum+x;
			num=num/10;
			if(x%2!=0)
			{
				System.out.println("count is"+count);
				count++;
				System.out.println("count is"+count);
			}
		}
		if(count<10)
			System.out.println("it is single digit");
		else 
			System.out.println("it is double digit");
		// TODO Auto-generated method stub

	}

}
