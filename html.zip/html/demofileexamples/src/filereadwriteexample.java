import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;


public class filereadwriteexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		File input=new File("input.txt");
		File output=new File("output.txt");
		try
		{
			
			FileInputStream fr=new FileInputStream(input);
			FileOutputStream fw=new FileOutputStream(output);	
			int ch=fr.read();
			while(ch!=-1)
			{
				fw.write(ch);
				ch=fr.read();
				//ch=(char) fr.read();
				//System.out.println(ch);
			}
		}
			
			catch(Exception e)
			{
			System.out.println(e);	
			}
				
		}
		
		
		
	}


