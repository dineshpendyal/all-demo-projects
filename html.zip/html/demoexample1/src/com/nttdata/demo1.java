package com.nttdata;
public class demo1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	String s="12345";	
	int k=s.length();
	System.out.println("total no of digits:"+k);
	
	}
	}
		//string s='12345';
		
		// TODO Auto-generated method stub
		//System.out.println("welcome");
		//int sum=0;
		/*for(int current=0;current<=10;current++)
		{
			sum=sum+current;
		}*/
		
	//}

