import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class stringexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try{
			//.int a=100;
			//int b=10000;
			
			String name="thirupati rao";
			String area ="btm layout";
			String purpose="pg";
			String location="bangalore";
			
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521"," TRDB12","TRDB12");
			Statement stmt=con.createStatement();
			//int x=stmt.executeUpdate("insert into nttjdbc values(10,1000,'name1')");
			//int x=stmt.executeUpdate("insert into nttjdbc values(100,10000,'str','location')");
			int x=stmt.executeUpdate("insert into stringtable values('"+name+"','"+area+"','"+purpose+"','"+location+"')");
			//String query="insert into nttjdbc values("+a+","+b+",'"+str+"','"+location+"')";
			//System.out.println(query);
			
			
			System.out.println(x);
			
			}
			catch(Exception e)
			{
			System.out.println(e);
				
			}
		}

		
		
	}

