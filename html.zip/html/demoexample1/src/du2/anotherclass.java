package du2;

public class anotherclass implements commoninterface{

	public void read(int x, int y) {
		// TODO Auto-generated method stub
		
	}



	public void calculate(int x, int y) {
		// TODO Auto-generated method stub
	int k=x*y;
	System.out.println(k);
	}

	/**
	 * @param args
	 */
	

}
