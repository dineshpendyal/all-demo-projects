package com.nttdata.course.domain;

public class Course {
private String CourseId;
private String CourseName;
private String ProfId;
public String getCourseId() {
	return CourseId;
}
public void setCourseId(String courseId) {
	CourseId = courseId;
}
public String getCourseName() {
	return CourseName;
}
public Course(String courseId, String courseName, String profId) {
	super();
	CourseId = courseId;
	CourseName = courseName;
	ProfId = profId;
}
public void setCourseName(String courseName) {
	
	CourseName = courseName;
}
public String getProfId() {
	return ProfId;
}
public void setProfId(String profId) {
	ProfId = profId;
}
//public CoursePreference getPreference() {
//	
//	return null;
//}

}
