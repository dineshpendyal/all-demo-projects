import java.util.Scanner;

class empdetails
{

	
		//int eid;
		int basicsalary;
		
		int netsalary(int sal)
		{
			int grosssalary,hra,da,netsalary,pf,it=0;
			hra=(int) (sal*0.1);
			da=(int) (sal*0.2);
		grosssalary=(int)((basicsalary+hra+da)*12);
		pf=(int)(12*(sal*0.15));
		 if(grosssalary<=500000)	
		 {
			 it=0;
		 }
		 else if(grosssalary>50000&&grosssalary<=1000000)
		 {
			 it=(int) (grosssalary*0.1);
		 }
		 else if(grosssalary>1000000)
		 {
			 it=(int) (grosssalary*0.15);
		 }
		return netsalary;
		
}
void read()
{
Scanner sc=new Scanner(System.in);
System.out.println("enter the details");
basicsalary=sc.nextInt();
//grade=sc.next();

}
public class employeesalary {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
 	}

}}
