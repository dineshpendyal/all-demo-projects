public class examprog4 {
    public static void main(String[] args) {
	int number = 123456;

	char firstDigit = String.valueOf(number).charAt(0);

        int lastDigit = number%10;

	System.out.println(number );
	System.out.println( firstDigit);
	System.out.println( lastDigit );


	}
}