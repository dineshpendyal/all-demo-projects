package domain;

public class CoursePreference {
private String CourseId;
private String Preference;
private String Studid;
public CoursePreference(String courseId, String preference) {
	super();
	CourseId = courseId;
	Preference = preference;
}

public CoursePreference(String studid,String courseId, String preference)
{
super();
Studid=studid;
CourseId = courseId;
Preference = preference;
}

public String getCourseId() {
	return CourseId;
}
public void setCourseId(String courseId) {
	CourseId = courseId;
}
public String getPreference() {
	return Preference;
}
public void setPreference(String preference) {
	Preference = preference;
}

public String getStudid() {
	return Studid;
}

public void setStudid(String studid) {
	Studid = studid;
}
}
