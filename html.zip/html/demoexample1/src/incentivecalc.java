import java.util.Scanner;
class employee
{
	int eid;
	String grade;
	int sales;
	int incentive(int sales,String grade)
	{
		int inc;
		if(sales>100&&gradwe.equalsIgnoreCase("one"))
		{
			inc=sales*10/100;
		}
		else if((sales>100&&grade.equalsIgnoreCase("two")))
				{
			inc=sales*20/100;
				}
		else
		{
			inc=sales*30/100;
		}
		return inc;
	}
	void read()
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the details");
	eid=sc.nextInt();
	grade=sc.next();
	sales=sc.nextInt();
	int x=incentive(sales,grade);
	
	}
}
	void display()
	{
		
	}
public class incentivecalc {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
