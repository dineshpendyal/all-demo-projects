package du2;

public class student {
	public int r=0;
	public int k=0;
	
	int sid;
	String name;
	int[] marks={10,60,20,30,50,25};
	void reqpassingmarks()
	{
		
		for(int i=0;i<marks.length;i++)
		{
			 r=0;	
			 r=marks[i];
			k=k+r;
		
			System.out.println(r);
		//return r;
		}
		//return r;
		if(r<200)
		{
			System.out.println("not enough marks");
			System.out.println("you need more"+(200-k)+"marks to pass");
		}
		
		
		}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
student obj1=new student();
obj1.reqpassingmarks();

	}
}

