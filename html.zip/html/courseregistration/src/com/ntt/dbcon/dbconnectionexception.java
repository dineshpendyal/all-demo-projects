package com.ntt.dbcon;

public class dbconnectionexception extends Exception{
	public dbconnectionexception(String msg, Throwable cause) {

		super(msg, cause);
	}

	public dbconnectionexception(String msg) {
		super(msg);
	}

	
	
	
}
