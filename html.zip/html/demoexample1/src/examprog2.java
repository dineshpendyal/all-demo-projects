
public class examprog2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 int x=1;
		 int count=1;
		 while(count<=10)
		 if(x/x==1)
		 {
			 System.out.println(x);
			 x++;
			 count++;
		 }
		
	}

}
