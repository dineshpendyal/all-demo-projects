import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


public class deleteexofpreparedstatement {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521"," TRDB12","TRDB12");
		//Statement stmt=con.createStatement();
		//PreparedStatement stmt=con.prepareStatement("insert into nttjdbc values(?)");
//		stmt.setInt(1, 1000);
		
		//PreparedStatement obj=con.prepareStatement("update nttjdbc set sal=sal+?");
		PreparedStatement obj=con.prepareStatement("delete ");
//		int x=obj.executeUpdate("update nttjdbc set sal=sal+?");
//	//stmt.setInt(2, 1);
	obj.setInt(1, 2000);
	//stmt.set
//		stmt.setString(3, "name3");
//		stmt.setString(4, "bangalore");
		
		
		
		obj.executeQuery();		
		
		
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
		
	}

}
