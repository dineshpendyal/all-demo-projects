package exampleofaggregation;

class student{
	
	int sid;
	String name;
	int[] marks={10,60,20,30,50,25};
	public student(int x,String y)
	{
		sid=x;
		name=y;
		
	}
	void avgmarks()
	{	int sum=0;
	int avg=0;
	
		for(int i=0;i<marks.length;i++)
		{
           sum+=marks[i];		
			
		}
		avg=sum/marks.length;
		if((35-avg)>0)
		{
			int reqmarks=(35-avg);
			System.out.println(reqmarks);
		}
		
		
	}
	
}






public class studentexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	student s=new student(100, "stu1");
	s.avgmarks();
	
	}

}
