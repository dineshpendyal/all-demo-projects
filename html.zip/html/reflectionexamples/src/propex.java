
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;


public class propex {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

Properties prop=new Properties();
Properties prop2=new Properties();
prop.setProperty("user", "gt602"); 
prop.setProperty("password", "welcome1234");
prop.setProperty("floor", "sixth");
prop.setProperty("location", "ser2");
FileOutputStream infile=new FileOutputStream("connectprop.properties");
prop.store(infile, "writing to properties file");
FileInputStream in=new FileInputStream("connectproperties2.properties");
//prop2.load(in);
prop2.load(in);
//prop2.save();
System.out.println(prop.getProperty("user"));
System.out.println(prop.getProperty("password"));
System.out.println(prop.getProperty("floor"));
System.out.println(prop.getProperty("location"));



	}

}
