package com.nttdata.course.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.nttdata.course.dbfw.ParamMapper;
import java.sql.SQLException;

import com.nttdata.course.dbfw.ResultMapper;
import com.nttdata.course.domain.Course;
import com.nttdata.course.domain.CoursePreference;
import com.nttdata.course.domain.Department;
import com.nttdata.course.domain.Professor;
import com.nttdata.course.domain.User;

public class SQLMapper {
	//public static final String FETCHROLEID=
		//"select * from country_081";
	public static final String FETCHROLEID=
		"select * from User1 where Userid=? and Password=?";
	public static final String SAVEPROFESSOR=
		"insert into Professor values(?,?,?)";
	
	public static final String SAVECOURSE=
			"insert into Course values(?,?,?)";
	public static final String SAVESTUDENT=
			"insert into Student values(?,?,?,?,?)";
	public static final String FETCHDEPARTMENT=
			"select * from Department";
	public static final String FETCHPROFESSOR=
			"select * from Professor";
	public static final String FETCHCOURSE=
			"select * from Course";
	public static final String FETCHSTUDENT=
			"select * from Student";
	public static final String FETCHPREFERREDCOURSE=
			"select  * from Stud_Course ";
	public static final String SAVEPREFERENCE=
			"insert into Stud_Course values(?,?,?)";
	public static final String FETCHSTUD_COURSE=
			"select count(Preference) from Stud_Course";
//public static final String NUMBERMAPPER=
	//	"select count(Preference) from Stud_Course";
	
	public static final ResultMapper NUMBERMAPPER=
			new ResultMapper() {
		public Object mapRow(ResultSet rs) throws SQLException {
			int count=rs.getInt(1);
			return count;
		//return ("select count(Preference) from Stud_Course");
	}

		
	};
	
	
	public static final ResultMapper USSERMAPPER = new ResultMapper()
	{
		public Object mapRow(ResultSet rs) throws SQLException
		{
			
			User u=new User(rs.getString("userid"),rs.getString("username"),rs.getString("password"),rs.getString("roleid"));
			return u;
		}
	};
	public static final ResultMapper PROFESSORMAPPER=new ResultMapper()
		{
			public Object mapRow(ResultSet rs) throws SQLException {
			String ProfId=	rs.getString(1);
			return ProfId;
			}
			
		};
		public static final ResultMapper COURSEMAPPER=
				new ResultMapper()
			{
				public Object mapRow(ResultSet rs) throws SQLException {
				String Courseid=	rs.getString(1);
				return Courseid;
				}
				
			};
			public static final ResultMapper STUDENTMAPPER=
					new ResultMapper()
				{
					public Object mapRow(ResultSet rs) throws SQLException {
					String Studentid=	rs.getString(1);
					return Studentid;
					}
					
				};
				public static final ResultMapper DEPARTMENTMAPPER=
						new ResultMapper()
					{
					
					
						public Object mapRow(ResultSet rs) throws SQLException {
						String DepartmentId=	rs.getString(1);
						String DepartmentName=	rs.getString(2);
						
						Department c=new Department(DepartmentId,DepartmentName);
						return c;
						}
						
					};
					public static final ResultMapper PROFESSORMAPPER1=
							new ResultMapper()
						{
						
						
							public Object mapRow(ResultSet rs) throws SQLException {
							String ProfessorId=	rs.getString(1);
							String ProfessorName=	rs.getString(2);
							String DepartmentId=	rs.getString(3);
							Professor c=new Professor(ProfessorId,ProfessorName,DepartmentId);
							return c;
							}
							
						};
						public static final ResultMapper COURSEMAPPER1=
								new ResultMapper()
							{
							
							
								public Object mapRow(ResultSet rs) throws SQLException {
								String CourseId=	rs.getString(1);
								String CourseName=	rs.getString(2);
								
								Course c=new Course(CourseId,CourseName,null);
								return c;
								}
								
							};
							public static final ResultMapper COURSEMAPPER2=
									new ResultMapper()
								{
								
								
									public Object mapRow(ResultSet rs) throws SQLException {
									String CourseId=	rs.getString(2);
									String Preference=	rs.getString(3);
									//String studid=rs.getString(1);
									CoursePreference c=new CoursePreference(CourseId,Preference);
									return c;
									}
									
								};
								
}
