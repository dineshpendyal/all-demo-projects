

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class cookieservlet2
 */
@WebServlet("/cookieservlet2")
public class cookieservlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public cookieservlet2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	try{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		//Cookie ck[]=request.getCookies();
		Cookie ck[]=request.getCookies();
		
//out.print("hello"+ck[0].getValue());
		
//		out.print("hello "+ck[0].getValue());
//		out.print("hello "+ck[1].getValue());
//		out.print("hello "+ck[2].getValue());
//		out.print("hello "+ck[3].getValue());
//		out.print("hello "+ck[4].getValue());
		for(int i=0;i<ck.length;i++)
		{
			out.print("hello "+ck[i].getValue());
		}
		
		
		out.close();
		
		
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	
	
	}

}
