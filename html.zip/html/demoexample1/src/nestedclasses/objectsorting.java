package nestedclasses;
import java.util.Arrays;
import java.util.Scanner;

class employeenttdata implements Comparable
{
int eid;
int salary;
String name;
public int compareTo(Object arg0) {
	// TODO Auto-generated method stub
	employeenttdata e1=(employeenttdata)arg0;
	
	
	return this.salary-e1.salary;
	//return this.name-e1.name;
}
	
	}

public class objectsorting {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
employeenttdata[] en=new employeenttdata[5];
for(int i=0;i<en.length;i++)
{
System.out.println("enter "+(i+1)+"th employee details");
en[i]=new employeenttdata();	
en[i].eid=sc.nextInt();
en[i].salary=sc.nextInt();
en[i].name=sc.next();


}
Arrays.sort(en);
for(int i=0;i<en.length;i++)
{
	System.out.println(en[i].eid+" "+en[i].salary+" "+en[i].name);
	}
	}

}
