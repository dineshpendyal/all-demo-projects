
package service;
//import java.sql.Date;
import java.util.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import dao.AdminDAO;
import dao.StudentDAO;
import dao.UserDAO;
import dbcon.DBConnectionException;
import dao.CourseDAOException;
import dbfw.DBFWException;
import domain.Course;
import domain.CoursePreference;
import domain.Professor;
import domain.StudPreference;
import domain.Student;
import domain.User;


public class CourseRegisterDriver {

	public static void main(String[] args) throws DBFWException, CourseDAOException, IOException, DBConnectionException, ParseException
	{
		SimpleDateFormat abc=new SimpleDateFormat("yyyy/mm/dd");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("....Enter user id...");
		String userid=sc.next();
		
		System.out.println("...Enter password....");
		String password=sc.next();
		
		CourseRegFacade crf=new CourseRegFacade();
		User u1=null;
		String student="2";
		String admin="1";
		int z=0;
		try
		{
			String conti=null;
			u1=crf.validateUser(userid, password);
			System.out.println("RoleId  "+u1.getRoleId());
			
			conti=u1.getRoleId();
			System.out.println(conti);
			
			if(conti=="null")
			{
				System.out.println("role id is null");
				
			}
			
				if(conti.equals("1")) 
				{
						
						System.out.println("admin logged in");   
						System.out.println("1.Add professor Details");
						System.out.println("2.Add Course Details");
						System.out.println("3.Add Student Details");
						System.out.println("enter your choice");
						
						String ch=sc.next(); 
						
						if(ch.equals("1"))
						{
							System.out.println("Enter professor Name");
							String pnme=sc.next();
							System.out.println("Enter the deptid");
							String did=sc.next();
							System.out.println("Enter the profid");
							String pid=sc.next();
							Professor p= new Professor(pid,pnme,did);
							String re=crf.saveProfessor(p);
							System.out.println("Professor details are saved");
							System.out.println("Professor ID generated "+pid);
						}
						if(ch.equals("2"))
						{
							System.out.println("Enter Courseid");
							String crid=sc.next();
							
							System.out.println("Enter the coursename");
							String cnme=sc.next();
							System.out.println("Enter the profid");
							String prid=sc.next();
							Course c= new Course(crid,cnme,prid);
							//String c1=crf.saveCourse(c);
//							c.getCourseId();
//							c.getCourseName();
//							c.getProfId();
							String cr=crf.saveCourse(c);
							System.out.println("Course details are saved");
							System.out.println("Course ID generated "+crid);
							System.out.println("Course name generated "+cnme);
						}
						if(ch.equals("3"))
						{
							System.out.println("Enter the studentID");
							String sid=sc.next();
							System.out.println("Enter the student name");
							String sn=sc.next();
							System.out.println("Enter the Student Address");
							String sad=sc.next();
							System.out.println("Enter the Student dob in the format(yyyy/mm/dd)");
							String date=sc.next();
							//Date date = (Date)abc.parse(sc.next());
							java.util.Date utildate=new java.util.Date(date);
							java.sql.Date edate=new java.sql.Date(utildate.getTime());
							
							System.out.println("Enter the student degree");
							String sde=sc.next();
							
							Student st=new Student(sid,sn,sad,edate,sde);
							String er=crf.saveStudent(st);
							System.out.println("Student details saved");
							System.out.println("Student id generated"+sid);
						}
						
						// System.out.println("test");
				}
						
						if(conti.equals("2"))
						{
							System.out.println("student logged in");
							System.out.println("1.Get all courses");
							System.out.println("2.Save preference");
							System.out.println("3.get preferred courses");
							System.out.println("enter your choice");
							String ch1 =sc.next();
							if(ch1.equals("1"))
							{
								List<Course> allcourses=new ArrayList<Course>();
								allcourses=crf.getAllCourses();
								System.out.println("CourseID\t\tCourseName\t\tProfessorID");
								for(Course c:allcourses)
								{
				                   System.out.println(c.getCourseId()+"\t\t\t"+ c.getCourseName()+"\t\t\t"+ c.getProfId());
									//System.out.println("CourseID "+c.getCourseId()+" CourseName "+c.getCourseName()+  "  ProfessorID " +c.getProfId());
//									System.out.println("Course name "+c.getCourseName());
//									System.out.println("Professor ID "+c.getProfId());
								}
							}
							if(ch1.equals("2"))
							{
								System.out.println("Enter student ID");
								String sid=sc.next();
								System.out.println("Enter Course ID");
								String cid=sc.next();
								System.out.println("Enter course preference");
								String cpref=sc.next();
								
								CoursePreference cp=new CoursePreference(cid,cpref);
								List<CoursePreference>lcp=new ArrayList<CoursePreference>();
								
								
								lcp.add(cp);
								StudPreference sp=new StudPreference(sid,lcp);
								int w=CourseRegFacade.savePrefCourses(sp);
		
								
		
								if(w!=0)
								{
									System.out.println("Student course preference saved successfully");
								}
								else
								{
									System.out.println("cannot save preferred course");
								}
								
							}
							if(ch1.equals("3"))
							{
								System.out.println("Enter student ID");
								String studID=sc.next();
								List<CoursePreference> course2=CourseRegFacade.getPrefCourse(studID);
								System.out.println(course2);
								  
								for(CoursePreference obj:course2)
								{
									System.out.println("studid :"+obj.getStudid()+ "Course :" +obj.getCourseId() +" Preference :"+  obj.getPreference());
								}
							}
							
						}
						
						
						
						
						
				
				System.out.println("out of switch this is the end");
//				conti=sc.next().toLowerCase();	
				
				
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
