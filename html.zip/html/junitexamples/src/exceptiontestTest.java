import junit.framework.TestCase;


public class exceptiontestTest extends TestCase {

	public void testDivide() {
		try
		{
			exceptiontest obj=new exceptiontest();
			obj.divide(10, 0);
			fail("did not throw an exception");
		}
		
		catch (Exception e)
		{
			System.out.println("from exceptiontesttest catch block");
		}
		//fail("Not yet implemented");
	
	}

}
