
public class arithmetic {

	int add(int x,int y)
	{
		return x+y;
		
	}	
	int sub(int x,int y)
	{
		return x-y;
		
	}	
	
	
	/**
	 * @param args
	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}
