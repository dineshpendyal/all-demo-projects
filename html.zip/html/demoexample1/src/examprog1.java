
public class examprog1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=10;
		int j=20;
		int k=30;
		int temp;
		
		if(i<j)
		{
		temp=j;
		if(j<k)
		{
			temp=k;
			System.out.println(temp);
		}
		else if(i>j)
		{
			temp=i;
			if(j>k)
			{
				temp=j;
				System.out.println(temp);
			}
			else {
				temp=k;
				System.out.println(temp);
			}
				
				}}
			}

}
