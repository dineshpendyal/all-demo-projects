package com.nttdata.collectionexamples;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class setexamples {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Set st=new HashSet();
st.add(10);
st.add("String123");
st.add(66.88);
st.add(true);
st.add(99.99f);
st.add(10);
Iterator itr=st.iterator();
while(itr.hasNext())
{
System.out.println(itr.next());	
}
		
		
	}

}
