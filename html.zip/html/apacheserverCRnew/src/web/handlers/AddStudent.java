package web.handlers;



import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import dbcon.DBConnectionException;
import mvc.HttpRequestHandler;
import dao.adminDAO;
import dao.CourseDAOException;
import dao.DAOAppException;
import dao.loginDAO;
import domain.user;
import domain.professor;
import service.courseregexception;
import service.courseregfacade;
import domain.course;
import domain.student;

public class AddStudent implements HttpRequestHandler {

	public static Logger log = Logger.getLogger(Login.class);

	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		String studId=request.getParameter("studId");
		 String txtStudentName = request.getParameter("txtStudentName");
		 String txtAddress=request.getParameter("txtAddress");
		//String profId=request.getParameter("txtAddress");
		 String txtDegree=request.getParameter("txtDegree");
		 Date dob;
		 
		try {
			dob = new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("txtDOB"));
			//adminDAO dao = new adminDAO();
			//adminDAO admin=new adminDAO();
		courseregfacade c=new courseregfacade();
		student st=new student(studId,txtStudentName,txtAddress,dob,txtDegree);
		  courseregfacade cdf=new courseregfacade();
		  try {
			  
			cdf.saveStudent(st);
			RequestDispatcher dispatcher = request.getRequestDispatcher("AddStudentSuccess.jsp");
			request.setAttribute("Name1", studId);
			dispatcher.forward(request, response);
			
			
			
		} catch (DBConnectionException | courseregexception
				| CourseDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		  
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		/* AdminDAO dao = new AdminDAO();
			AdminDAO admin=new AdminDAO();
			CourseRegFacade c=new CourseRegFacade();
		 Student st=new Student(studId,studentName, addressed,dob,degree);*/
         
       
        

	    //String id=admin.saveProfessor(professor);
	   //return id;
		
		}
	}

