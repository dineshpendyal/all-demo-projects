package arrayofobjectsexamples;

import java.util.Scanner;

class employee
{
	int age;
	int salary;
	String name;
	void display(employee[] r)
	{
		for(int i=0;i<r.length;i++)
		{
System.out.println(r[i].age);
System.out.println(r[i].salary);
System.out.println(r[i].name);
	r[i].name="nttemployee";
		
		}
	}
}
public class arrayofobjects {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
employee e1=new employee();		
employee[] e=new employee[5];
Scanner sc=new Scanner(System.in);
sc.close();
for(int i=0;i<e.length;i++)
{
	System.out.println("enter the details of "+(i+1)+"th employee");
	e[i]=new employee();
	e[i].age=sc.nextInt();
	e[i].salary=sc.nextInt();
	e[i].name=sc.next();
			
}
e1.display(e);

	
	}

}
