import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


class demo
{
int id=10;
String fromtype="normL";
int contact=123;
String regaddrtess="BNGLR";

}


public class sendingvaluestotable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521"," TRDB12","TRDB12");
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select *from empdetails ");
			
			List a=new ArrayList();
			demo d=new demo();
			a.add(d);
			//System.out.println(d.id);
				
			
			
			while(rs.next())
				{
				
						//stmt.executeUpdate("update empdetails set name='john'");
				}

		  
			
		
		Iterator itr=a.iterator();
		while(itr.hasNext())
		{
			//demo d=new demo();
			//d=(registration)itr.next();
		//	System.out.println(e.id);
			//System.out.println(e.name);
			
			
		}
		
		}  
		catch(Exception e)
		{
			
		System.out.println(e);	
		}
		
		
		
		
	}

}
