package com.nttdata.collectionexamples;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class listusinglinkedlist {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List ll1=new LinkedList();
		List ll2=new LinkedList();
		
		ll1.add(10);
		ll1.add("string123");
		ll1.add(true);
		ll1.add(67.9898);
		ll1.add(90.999f);
		
		ll2.add(20);
		ll2.add("String2");
		
		Iterator itr=ll1.iterator();
		ListIterator litr=ll1.listIterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		//while(itr.hasPrevious())
		//{
			//System.out.println(itr.next());
		//}
		
	}

}
