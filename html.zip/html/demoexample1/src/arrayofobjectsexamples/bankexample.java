package arrayofobjectsexamples;
import java.util.Scanner;


public class bankexample {
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=1;
		Scanner sc=new Scanner(System.in);
		String[] users={"user1","user2"};
		String[] passwords={"password1","password2"};
//k:

	//System.out.println("enter username");
		//String user=sc.next();
		//System.out.println("enter password");
		//String pass=sc.next();
		for(int i=0;i<users.length;i++)
		{
			System.out.println("enter username");
			String user=sc.next();
			System.out.println("enter password");
			String pass=sc.next();
	  if(users[i].equals(user) && passwords[i].equals(pass))
		{
			System.out.println("welcome"+user);
			break;
		}
		else if(users[i].equals(user) && passwords[i]!=pass)
		{
		count++;
		System.out.println("password is wrong");
		System.out.println(count);
		//break k;
		
		}}
		if(count>=2)
		{
			System.out.println("user does not exists");
		}
		


			
}



	
	}


