import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;


public class PropertiesTest {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 
	         Properties prop2=new Properties();
	         FileInputStream in=new FileInputStream("con2.properties");
	         prop2.load(in);
	         System.out.println(prop2.getProperty("user"));
	         System.out.println(prop2.getProperty("password"));
	         System.out.println(prop2.getProperty("floor"));
	         System.out.println(prop2.getProperty("location"));
	}

}

2)package com.nttdata;

import java.util.Scanner;

public class InvalidEmployee extends Exception {

	String emp_id;
	void readDetails(InvalidEmployee  i)throws InvalidEmployee
	{
		
		if(emp_id=="null")
		{
			throw new InvalidEmployee();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
InvalidEmployee u=new InvalidEmployee();
u.emp_id="null";
try
{
	u.readDetails(u);

}
catch(InvalidEmployee e)
{
	System.out.println(e);
}

}}
