
public class calc {

	public int add()
	{
		
		System.out.println("add");
		
		return 0;
		
		
	}
	public int sub()
	{
		
		System.out.println("add");
		
		return 0;
		
		
	}
	
	
	
}
