
public class examprog5 {
	int read()
	{
		int x=1;
		return x;
	}
void write()
{
	int a=1;
	int b=2;
	int c=0;
	while(c<=3)
	{
		if(a==2)
		
		continue;
		
		a++;
		System.out.println(a);
		c++;
	}

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		examprog5 obj1=new examprog5(); 
		obj1.write();
		
	}
	

}
