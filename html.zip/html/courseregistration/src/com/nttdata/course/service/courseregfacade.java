package com.nttdata.course.service;

import com.ntt.dbfw.DBFWException;
import com.nttdata.course.dao.coursedaoexception;
import com.nttdata.course.dao.userdao;
import com.nttdata.course.domain.user;

public class courseregfacade {

//validateuser();
//saveprofessor();
//savecourse();
//savestudent();
//getallcourses();
//getprefcourses();
//saveprefcourses();
//getallprof();
//getalldept();

//user uobj=null;
	public static user validateuser(final String x,final String y) throws coursedaoexception
	{
		userdao obj=new userdao();
		user k=obj.validateuser(x, y);
        	
		return k;
		
		
	}
	

}