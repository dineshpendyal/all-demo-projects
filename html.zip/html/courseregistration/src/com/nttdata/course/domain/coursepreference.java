package com.nttdata.course.domain;

public class coursepreference {

	private String courseid;
	private String preference;
	public String getCourseid() {
		return courseid;
	}
	public void setCourseid(String courseid) {
		this.courseid = courseid;
	}
	public String getPreference() {
		return preference;
	}
	public void setPreference(String preference) {
		this.preference = preference;
	}

//		public coursepreference(String x,String y) 
//			{
//	           	this.courseid=x;
//	           	this.preference=y;
//	
//			}
	
}
