
public class examprog6 {
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number = 12345;

		char firstDigit = String.valueOf(number).charAt(0);
		System.out.println(firstDigit);
		String str1="dinesh";
		String str2="dineshkumar";
		
		
	boolean b=str1.equals(str2);
	System.out.println(b);
	int x=str1.indexOf('e');
	System.out.println(x);
	
	}

}
