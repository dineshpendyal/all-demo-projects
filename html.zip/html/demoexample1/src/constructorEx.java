
class employee3
{
	int eid;
	String name;
	int sal;
	public employee3(int x, String y)
	{
		eid=x;
		name=y;
	}
   public employee3()
   {
	   eid=0;
	   name="ntt";
   }
   public employee3(int x, String y, int salary)
	{
		eid=x+20;
		name=y;
		sal=salary;
	}
}



public class constructorEx {

	/**
	 * @param args
	 */
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		employee3 e= new employee3(); // OVER WRITING DEFAULT CONSTRUCTOR
        employee3 e1 = new employee3(10,"ntt1");
        employee3 e2 = new employee3(20,"ntt2");
        employee3 e3 = new employee3(30,"ntt3");
        employee3 e4 = new employee3(40,"ntt3",30000);
        
        System.out.println(e.eid);
        System.out.println(e1.eid);
        System.out.println(e2.eid);
        System.out.println(e3.eid);
        System.out.println(e4.eid);
        
	}

}
