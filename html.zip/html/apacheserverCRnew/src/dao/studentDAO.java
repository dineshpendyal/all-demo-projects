package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import dbcon.ConnectionHolder;
//import com.ntt.dao.SQLMapper;
//import com.ntt.dao.SQLMapper;

import dbcon.DBConnectionException;
import dbfw.DBFWException;
import dbfw.DBHelper;
import dbfw.ParamMapper;
import domain.course;
import domain.coursepreference;
import domain.studentpreference;

public class studentDAO {
	static Logger log=Logger.getLogger(adminDAO.class);
	public List<course> getAllCourse() throws CourseDAOException,DBFWException,DBConnectionException{
		List courses=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetchig");
			courses=DBHelper.executeSelect(con,SQLmapper.FETCHCOURSE,SQLmapper.COURSEMAPPER);
			
		
			System.out.println(courses);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return courses;
	}
	public int saveCoursePref( final studentpreference studPref) throws CourseDAOException
	
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper INSERTPCOURSEPREFERENCE=new ParamMapper()
			{

				
				public void mapParams(PreparedStatement preStmt) throws SQLException {
					
					preStmt.setString(1, studPref.getStudId());
					preStmt.setString(2,studPref.getPrefCourse().get(0).getCourseId());
					preStmt.setString(3,studPref.getPrefCourse().get(0).getPrefCourse());
					}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLmapper.INSERTCOURSEPREFERENCE,INSERTPCOURSEPREFERENCE);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}
	//insert
	
	public List<coursepreference> getPrefCourses(final String studId) throws CourseDAOException, DBFWException, DBConnectionException
	
	{
		List<coursepreference> preferences=null;
		ConnectionHolder ch=null;
		Connection con=null;
		ParamMapper mapParam= new ParamMapper(){
			public void mapParams(PreparedStatement pStmt) throws SQLException{
				pStmt.setString(1,studId);
			}
		};
		
		
		
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			log.debug("fetchig");
			preferences=DBHelper.executeSelect(con,SQLmapper.FETCHPREFERENCE,mapParam,SQLmapper.PREFERENCEMAPPER);
					
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db"+e);
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return preferences;
		
	}
	//getcoursePreferences
		
		
		
		
		
		
		
	}
	
	

