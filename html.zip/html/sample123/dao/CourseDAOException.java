package com.nttdata.course.dao;

public class CourseDAOException extends Exception {
		// TODO Auto-generated method stub
public CourseDAOException(String message,Throwable cause)
{
	super(message,cause);
}
public CourseDAOException(String message)
{
	super(message);
}
	}


