import java.util.Scanner;
public class scannerdemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc= new Scanner(System.in);
int age = sc.nextInt();
System.out.println("Age: "+age); 
	}

}
