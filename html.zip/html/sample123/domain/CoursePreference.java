package com.nttdata.course.domain;

public class CoursePreference {
private String CourseId;
private String Preference;
public CoursePreference(String courseId, String preference) {
	super();
	CourseId = courseId;
	Preference = preference;
}



public String getCourseId() {
	return CourseId;
}
public void setCourseId(String courseId) {
	CourseId = courseId;
}
public String getPreference() {
	return Preference;
}
public void setPreference(String preference) {
	Preference = preference;
}
}
