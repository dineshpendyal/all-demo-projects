package reflectionexamples;

interface inter1
{
	
}
interface inter2
{
	
}

interface inter3
{
	
}

class grandfather
{
	
}
class father extends grandfather 
{
	}
public class kid extends father implements inter1,inter2,inter3 {
	public String name;
	public int age;
	
	public kid()
	{
		//name=y;
		//age=x;
	}
	
	public kid(int x)
	{
//		name=y;
//		age=x;
	}	
	
	public kid(int x,int y)
	{
//		name=y;
//		age=x;
	}
	
	
	
public kid(int x,String y)
	{
		name=y;
		age=x;
	}



public int read(int x,String y)
{
	System.out.println(x);
	System.out.println(y);
	
return 0;	
}

public int read(int x)
{
	System.out.println(x);
return 0;	
}

public void display(int x,String y)
{
	System.out.println(x);
	System.out.println(y);
}
	/**
	 * @param args
	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}

}
