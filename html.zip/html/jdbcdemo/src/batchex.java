import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class batchex {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521"," TRDB12","TRDB12");
			Statement stmt=con.createStatement();
			stmt.addBatch("insert into coffee values('c1',10,100,1000,10000)");
			stmt.addBatch("update coffee set sellerid=215 where sellerid=100");
			
			stmt.addBatch("insert into coffee values('c2',20,200,2000,20000)");
			stmt.addBatch("insert into coffee values('c3',30,300,3000,30000)");
			stmt.addBatch("insert into coffee values('c4',40,400,4000)");
			//batch will throw an error but the previous ststements are executed
			stmt.addBatch("insert into coffee values('abc',30,300,3000,30000)");
			
			int[] x=stmt.executeBatch();
		
		for(int i:x)
		{
			System.out.println(i);
			
		}
			
		}
		
catch(Exception e)
{
System.out.println(e);	
}
		
	}

}
