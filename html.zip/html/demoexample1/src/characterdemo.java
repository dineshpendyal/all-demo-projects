
public class characterdemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Character a1=new Character('a');
Character a2=new Character('a');
Character a3=new Character('b');
String str1="nttdata";
String str2="nttdatabangalore";
int difference=str2.compareTo(str1)	;

	}

}
