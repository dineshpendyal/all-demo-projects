package domain;

public class Professor {
private String ProfId;
private String ProfName;
private String DeptId;
public Professor(String profId, String profName, String deptId) 
{
	super();
	ProfId = profId;
	ProfName = profName;
	DeptId = deptId;
}


public  Professor(String x)
{
	x=ProfId;
	System.out.println(x);
}

public String getProfId() {
	return ProfId;
}
public void setProfId(String profId) {
	ProfId = profId;
}
public String getProfName() {
	return ProfName;
}
public void setProfName(String profName) {
	ProfName = profName;
}
public String getDeptId() {
	return DeptId;
}
public void setDeptId(String deptId) {
	DeptId = deptId;
}

}
