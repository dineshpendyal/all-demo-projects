package du2;

public class bank {

	
	private String name; 
	   
	 
	 bank(String name) 
	 { 
	     this.name = name; 
	 } 
	
	 public String getBankName() 
	 { 
	     return this.name; 
	 } 
	 
	

}
