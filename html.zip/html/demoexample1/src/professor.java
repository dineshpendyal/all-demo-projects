import java.util.Scanner;

class professordata
{
int pid;
String branch;
int salary;
void read()
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the details");
	pid=sc.nextInt();
	branch=sc.next();
	salary=sc.nextInt();
	sc.close()
;		}
void display()
	{
	System.out.println(pid);
	System.out.println(branch);
	System.out.println(salary);
	}
}
public class professor 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
	professordata data=new professordata();
	data.read();
	data.display();
		// TODO Auto-generated method stub

	}

}
