package inheritanceexamples;

public class manager {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		void details()
		{
			//int eid;
			//System.out.println(eid);
		}
	}

}
