package com.nttdata.collectionexamples;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class listusingarraylist {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List l=new ArrayList();
		List l2=new ArrayList();
		l2.add(20);
		l2.add("String2");
		l.add(10);
		l.add("string123");
		l.add(true);
		l.add(67.9898);
		l.add(90.999f);
		System.out.println("before");
		Iterator itr=l.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		for(Object o:l)
		{
			System.out.println(o);
			
		}
		l.addAll(l2);
		System.out.println("after");
		
		//l.remove(2);
		for(Object o:l)
		{
			System.out.println(o);
			
		}
		
		
	}

}
