package com.nttdata.course.domain;

import java.util.List;
import java.util.ArrayList;

public class studpreference {

	private String studid;
	//private List  prefcourse;
	private List <coursepreference> prefcourse;
	
	public void addpref(String courseid,int preference)
	{
		int primaryreference;
		int secondaryreference;
		
		
	}

	public String getStudid() {
		return studid;
	}

	public void setStudid(String studid) {
		this.studid = studid;
	}

	public List<coursepreference> getPrefcourse() {
		return prefcourse;
	}

	public void setPrefcourse(List<coursepreference> prefcourse) {
		this.prefcourse = prefcourse;
	}
	
	
//	public studpreference(String x)
//	{
//		this.studid=x;
//		
//	}
//	
	
	}
