package arrayofobjectsexamples;

import java.util.Scanner;


public class bankexampleusingarrayofobjects {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
int count=0;
customer[] c=new customer[5];
Scanner sc=new Scanner(System.in);
for(int i=0;i<c.length;i++)
{
c[i]=new customer();
c[i].username=sc.next();
c[i].password=sc.next();
c[i].balance=sc.nextInt();
}
customer1 c1=new customer1();
String user;
String password;
while(count<=3)
{
	System.out.println("enter username");
	user = sc.next();
	System.out.println("enter password");
	password = sc.next();
	

//String username;
//String password;

for(int i=0;i<c.length;i++)
{
if(c[i].username.equals(user) && c[i].password.equals(password))
{
	System.out.println("welcome"+user);
	System.out.println("1.credit");
	System.out.println("2.debit");
	System.out.println("3.balance enquiry");
	int choice=sc.nextInt();
	//int choice;
	c1.operations(c[i],choice);
    System.out.println(c[i].balance);
	return;
	


}
else{
	count++;
	}
}
}
	}}


