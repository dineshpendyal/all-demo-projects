
public class fordemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] marks={10,20,30,40,50};
for(int x: marks)
{
	System.out.println(x);
}
	}

}
