public class Employee
{
	private int employeeid;
	private String employeeName;
	private int basic;
	private int houserentallowance;
	private int providentfund;
	private int dearnessallowance;
	public Employee()
	{
		
	}
	public  void setEmploeeId
	
}



















public class javabeanemployee {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
