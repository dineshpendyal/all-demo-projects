import java.util.Scanner;


public class employeid {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int[] count=new int[3];
		Scanner Sc=new Scanner(System.in);
		emp[] e1=new emp[5];
		for(int i=0;i<e1.length;i++)
				{
					e1[i]=new emp();
					System.out.println("enter eid");
					e1[i].eid=sc.nextInt();
					System.out.println("enter either 1,2 or 3");
					e[i].deptid=Sc.nextInt();
					
				}
		for(int i=0;i<e1.length;i++)
		{
			if(e1[i].deptid==1)
			{
				count[0]++;
				
			}
			else if(e1[i].deptid==2)
			{
				count[1]++;
				
			}
			else 
			{
				count[2]++;
				
			}
			for(int i=0;i<count.length;i++))
			{
				System.out.println("enter eid");
			}
		}
		// TODO Auto-generated method stub

	}

}
