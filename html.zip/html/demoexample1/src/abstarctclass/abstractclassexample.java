package abstarctclass;

abstract class student
{
	int sid;
	final String sname="student";
	abstract void read1();
void read2()
{
	System.out.println("read2 method");
	
}
class professor extends student
{
	void read1()
{
	System.out.println("read method");
}
	}
	}

public class abstractclassexample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		professor p1=new professor();
		p1.read1();
		System.out.println();

	}

}
