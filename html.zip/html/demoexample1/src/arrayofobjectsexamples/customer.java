package arrayofobjectsexamples;

import java.util.Scanner;

public class customer{
	String username;
	String password;
	 int balance;
	 
	 void operations(customer c,int choice)
	 {
	 	Scanner sc=new Scanner(System.in);
	 	switch(choice)
	 	{
	 	case 1:
	 		System.out.println("enter amount to credit");
	 		int amount=sc.nextInt();
	 		c.balance=c.balance+amount;
	 		break;
	 	case 2:
	 		System.out.println("enter the amount toi debit");
	 		amount=sc.nextInt();
	 		if(c.balance>=amount)
	 		{
	 			c.balance=c.balance-amount;
	 		}
	 		else{
	 			System.out.println("insufficent amount");
	 			
	 		    }
	 	case 3:
	 		System.out.println(c.balance);
	 	}
	 	
	 	
	 }



}
