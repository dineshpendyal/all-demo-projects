package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import dbcon.ConnectionHolder;
import dbcon.DBConnectionException;
import dbfw.DBFWException;
import dbfw.DBHelper;
import dbfw.ParamMapper;
import domain.user;
import dao.SQLmapper;

public class loginDAO {
	static Logger log = Logger.getLogger(loginDAO.class);

	public List validateUser(final String userid,final String password) throws DAOAppException {
		List res = null;
		ConnectionHolder ch = null;
		Connection con = null;
		try {
			ch = ConnectionHolder.getInstance();
			con = ch.getConnection();
			ParamMapper paramMapper = new ParamMapper() {

				@Override
				public void mapParams(PreparedStatement pStmt)throws SQLException {
				pStmt.setString(1, userid);
				pStmt.setString(2, password);
			}
			};
			res = DBHelper.executeSelect(con, SQLmapper.FETCH_USER,paramMapper, SQLmapper.MAP_USER);

//			if(res= null)
//			{
//				System.out.println("invalid User");
//			}
			
			
		} catch (DBConnectionException e) {
			log.error(e);
			throw new DAOAppException(e);
		} catch (DBFWException e) {
			throw new DAOAppException(e);
		}
		return res;

	}
	public user validateAUser(final int pid) throws DAOAppException {
		//List res = null;
		ConnectionHolder ch = null;
		Connection con = null;
		List res=null;
		user us=null;
		try {
			ch = ConnectionHolder.getInstance();
			con = ch.getConnection();
			ParamMapper userParamMapper = new ParamMapper() {

				@Override
				public void mapParams(PreparedStatement pStmt)
						throws SQLException {
					pStmt.setInt(1, pid);
				}
			};
			res = DBHelper.executeSelect(con, SQLmapper.FETCH_AUSER,
					userParamMapper, SQLmapper.MAP_AUSER);
			us=(user)res;
			/*Iterator itr=res.iterator();
			
			while(itr.hasNext())
			{
				 us=(User)itr.next();
			}
			*/

		} catch (DBConnectionException e) {
			log.error(e);
			throw new DAOAppException(e);
		} catch (DBFWException e) {
			throw new DAOAppException(e);
		}
		return us;

	}
	}
