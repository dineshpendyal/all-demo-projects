package reflectionexamples;

import java.lang.reflect.Constructor;

public class sampleconstructor {

	/**
	 * @param args
	 */
	
static void printconstructors(Object o)
{
Class c=o.getClass();
 Constructor[] constructors=c.getConstructors();
 for(int i=0;i<constructors.length;i++)
 {
	 System.out.println("");
	 Class[] parametertypes=constructors[i].getParameterTypes();
	 for(int j=0;j<parametertypes.length;j++)
	 {
		System.out.println(parametertypes[j].getName()); 
	 }
 }
	 
 
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

kid k=new kid();
//showConstructors(k);
//String s= new String();
//showConstructors(s);
printconstructors(k);	
	
	}

}
