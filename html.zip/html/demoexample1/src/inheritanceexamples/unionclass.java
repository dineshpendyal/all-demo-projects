package inheritanceexamples;

public class unionclass implements interestrate {

	/**
	 * @param args
	 */
	

	public int giveinterest() {
		int ir=(int)(x*0.15f
				
				);
		return ir;
		// TODO Auto-generated method stub
		
}}
