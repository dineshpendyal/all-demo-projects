package service;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import dbcon.DBConnectionException;
import dbfw.DBFWException;
import dao.adminDAO;
import dao.CourseDAOException;
import dao.studentDAO;
import dao.userDAO;
import domain.course;
import domain.coursepreference;
import domain.department;
import domain.professor;
import domain.studentpreference;
import domain.student;
import domain.user;

public class courseregfacade {
/*public User validateUser(String userId,String passwd) throws CourseRegException, SQLException, CourseDAOException, ClassNotFoundException
{    UserDAO userdao=new UserDAO();
     User recdUser;
	     recdUser=userdao.validateUser(userId, passwd);
	     return recdUser;
}*/
public String saveProfessor(professor professor) throws courseregexception, CourseDAOException, DBConnectionException
{   adminDAO admin=new adminDAO();
    String result=admin.saveProfessor(professor);
   return result;
	
}
public String saveStudent(student sd) throws courseregexception, CourseDAOException, DBConnectionException
{   adminDAO admin=new adminDAO();
    String id=admin.saveStudent(sd);
   return id;
	
}
public String saveCourse(course c) throws courseregexception, CourseDAOException, DBConnectionException
{
	adminDAO admin=new adminDAO();
    String courseId=admin.saveCourse(c);
   return courseId;
}
//public List<Professor> getAllProf() throws courseregexception, DBFWException, DBConnectionException, CourseDAOException
//{    List<Professor> professors;
//adminDAO admin=new adminDAO();
//     professors= admin.getAllProf();
//     return professors;
//}
//public List<Department> getAllDept() throws courseregexception, DBFWException, DBConnectionException, CourseDAOException
//{
//	List<Department> departments;
//	adminDAO admin=new adminDAO();
//   departments= admin.getAllDept();
//   return departments;
//}
public List<course> getAllCourse() throws courseregexception, DBFWException, DBConnectionException, CourseDAOException
{     List<course> courses;
       studentDAO studentDao=new studentDAO();
       courses=studentDao.getAllCourse();
       return courses;
}
//}////-----------------------rectify this
//public int savePrefCourses(StudPreference studPref) throws courseregexception, CourseDAOException
//{
//    StudentDAO studentDao=new StudentDAO();
//    int numRows=studentDao.saveCoursePref(studPref);
//    return numRows;
//    
//    
//}
public List<coursepreference> getPrefCourses(String studId)  throws courseregexception, DBFWException, DBConnectionException, CourseDAOException
{   studentDAO studao=new studentDAO();
java.util.List<coursepreference> cli=new ArrayList<coursepreference>();
try{
	cli=studao.getPrefCourses(studId);
}
catch(CourseDAOException e){
	throw new courseregexception("Invalid");
//	System.out.println("exception in crf: "+e);
}
//return cli;
//}
return cli;


}}
