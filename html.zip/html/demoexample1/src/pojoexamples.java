class student2
{
	private int sid;
	private int avg_marks;
	private String name;
	void display(student2 s)
	{
		System.out.println("welcome"+s.name);
		System.out.println("your avg marks"+s.avg_marks);
	}
	
	/**
	 * @return the sid
	 */
	public int getSid() {
		return sid;
	}
	/**
	 * @param sid the sid to set
	 */
	public void setSid(int sid) {
		this.sid = sid;
	}
	/**
	 * @return the avg_marks
	 */
	public int getAvg_marks() {
		return avg_marks;
	}
	/**
	 * @param avg_marks the avg_marks to set
	 */
	public void setAvg_marks(int avg_marks) {
		this.avg_marks = avg_marks;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
}



public class pojoexamples {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
student2 std=new student2();
System.out.println("student id");
std.setSid(10);
std.setName("student1");
	std.setName("student1");
	std.setAvg_marks(70);
	std.display(std);
	}

}
