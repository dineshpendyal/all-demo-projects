package du2;

public class bankemployee {
	
	private String name; 
	   
	  
	 bankemployee(String name)  
	 { 
	     this.name = name; 
	 } 
	   
	 public String getEmployeeName() 
	 { 
	     return this.name; 
	 }  
	

}
