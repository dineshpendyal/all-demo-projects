
public class multiplydigits {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int x=12345;
		int multiply=1;
		int newnum;
		while(x%10!=0)
		{
			newnum=x%10;
			multiply=multiply*newnum;
			x=x/10;
		}
		System.out.println(multiply);
		// TODO Auto-generated method stub

	}

}
