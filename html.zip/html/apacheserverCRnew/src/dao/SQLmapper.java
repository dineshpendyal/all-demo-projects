package dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import dbfw.ResultMapper;
import domain.course;
import domain.coursepreference;
import domain.department;
import domain.professor;
import domain.user;
//import domain.Course;
//import domain.CoursePreference;
//import domain.Department;
//import domain.Professor;

public class SQLmapper {

	public static final String FETCH_USER = "select * from userdetails where userid=? and password=?";
	public static final String FETCH_AUSER = "select employeeId from user_info where portalid=?";
	public static final ResultMapper MAP_USER = new ResultMapper() {

		@Override
		public Object mapRows(ResultSet rs) throws SQLException {
			user user = new user();
			user.setUserId(rs.getString("userid"));
			user.setPassword(rs.getString("password"));
			user.setRoleId(rs.getString("roleid"));
			return user;
			
		}
	};
	public static final ResultMapper MAP_AUSER = new ResultMapper() {

		@Override
		public Object mapRows(ResultSet rs) throws SQLException {
			user user = new user();
			user.setRoleId(rs.getString("roleid"));
			return user;
			
		}
	};
	public static final String ADD_USER = "insert into userdetails(userid,username,password,roleid) values(?,?,?,?)";
	public static final String FETCHCOUNTRY=
			"select * from country_081";
	public static final String FETCHPREFERENCE=
			"select courseId,PREFERENCE from stud_course where STUDID=? ";
	public static final String FETCHCOURSE=
			"select * from course";
	public static final String FETCHDEPARTMENT=
			"select * from department";
	public static final String FETCHPROFESSOR=
			"select * from professor";
//		public static final String FETCHCOUNTRYID=
//			"select id,name from country_081 where id=? and name=?";
		public static final String INSERTPROFESSOR=
			"insert into professor  values(?,?,?)";//PROFESSOR_SEQ1.nextval
		public static final String INSERTCOURSE=
				"insert into course  values(?,?,?)";
		public static final String INSERTSTUDENT=
				"insert into student  values(?,?,?,?,?)";
		public static final String INSERTCOURSEPREFERENCE=
				"insert into stud_course  values(?,?,?)";
		
		
		//public static final String PROFESSOR_SEQUENCE="select PROFESSOR_SEQUENCE.nextval from dual";
//		public static final String PROFESSOR_SEQUENCE="select PROFESSOR_SEQ1.nextval from dual";
//		public static final String COURSE_SEQUENCE="select COURSE_SEQ1.nextval from dual";
		public static final ResultMapper COURSE_SEQ_MAP=new ResultMapper(){
			public Object mapRows(ResultSet rs) throws SQLException{
				return rs.getString(1);
			}
		};
		public static final ResultMapper DEPARTMENTMAPPER=
				new ResultMapper()
			{
				public Object mapRows(ResultSet rs) throws SQLException {
				String id=	rs.getString(1);
				String name=rs.getString(2);
				department c=new department(id,name);
					return c;
				}//mapRow
				
			};
			public static final ResultMapper PROFESSORMAPPER=
					new ResultMapper()
				{
					public Object mapRows(ResultSet rs) throws SQLException {
					String id=	rs.getString(1);
					String name=rs.getString(2);
					String deptid=rs.getString(3);
					professor c=new professor(id,name,deptid);
						return c;
					}//mapRow
					
				};
				public static final ResultMapper COURSEMAPPER=
						new ResultMapper()
					{
						public Object mapRows(ResultSet rs) throws SQLException {
						String id=	rs.getString(1);
						String name=rs.getString(2);
					    String profId=rs.getString(3);
						course c=new course(id,name,profId);
						return c;
						}//mapRow
						
					};
					/*public static final ResultMapper PREFERENCEMAPPER=
							new ResultMapper()
						{
							public Object mapRow(ResultSet rs) throws SQLException {
							String id=	rs.getString(1);
							//String cid=rs.getString(2);
							//String prefer=rs.getString(3);
				            CoursePreference cp=new CoursePreference(id);
								return cp;
							}//mapRow
							
						};*/
					public static final ResultMapper PREFERENCEMAPPER = new ResultMapper(){
						public Object mapRows(ResultSet rs) throws SQLException{
							coursepreference cp=new coursepreference(rs.getString("courseid"),rs.getString("preference"));
							return cp;
						}
					};
						
					static final ResultMapper PROFESSOR_MAP=new ResultMapper(){
						public Object mapRows(ResultSet rs) throws SQLException{
							return rs.getString(1);
						}
					};
					static final ResultMapper COURSE_MAP=new ResultMapper(){
						public Object mapRows(ResultSet rs) throws SQLException{
							return rs.getString(1);
						}
					};
							
							/*static final ResultMapper PROFESSOR_MAP=new ResultMapper(){
								public Object mapRow(ResultSet rs) throws SQLException{
									return rs.getString(1);
								}
							};*/


}

//create table user_info(name varchar2(20),employeeId int,technology varchar2(20),password varchar2(20),portalid int)

