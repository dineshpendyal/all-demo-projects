

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class serv1
 */
@WebServlet("/serv1")
public class serv1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public serv1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//System.out.println("hello");
	String str1=req.getParameter("username");
	String str2=req.getParameter("password");
	String str3=req.getParameter("gender");
	String str4[]=req.getParameterValues("hobbies");
//	String str5=req.getParameter("gender");
//	String str6=req.getParameter("gender");
	
PrintWriter pr=res.getWriter();
pr.print("<form method='get' action='serv2'>"+
"<input type='text' name='text1' value='"+str1+"'/>"+
"<input type='password' name='text2'/>"+
"<input type='submit' value='login'/></form>");


//pr.print("user"+str1+"password"+str2+"gender"+str3);
//for(int i=0;i<str4.length;i++)
//{
//pr.print(str4[i]+" ");
//	//System.out.println(str4[i]+" ");	
//
//}
	
	//	System.out.println(str1);
//	System.out.println(str2);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//System.out.println("post method");
		doGet(request, response);
	}

}
