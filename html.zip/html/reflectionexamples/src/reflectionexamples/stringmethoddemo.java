package reflectionexamples;

import java.lang.reflect.Method;

public class stringmethoddemo {

	static void printmethodinfo(String str) throws ReflectiveOperationException,ClassNotFoundException
	{
		Class StringClass=Class.forName(str);
		Method[] stringMethods=StringClass.getDeclaredMethods();
		
	for(int i=0;i<stringMethods.length;i++)
	{
		String methodName=stringMethods[i].getName();
		System.out.println(methodName);
	    Class returnType=stringMethods[i].getReturnType();
	    System.out.println(returnType.getName());
	    System.out.println("parameter list:");
	System.out.println();
	Class[] params =stringMethods[i].getParameterTypes();
	for(int j=0;j<params.length;j++)
	{
	System.out.println(params[j].getName()+"");	
	}
	
   }
		
}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//String str="java.lang.String";
		String str="reflectionexamples.kid";
		try
		{
			printmethodinfo(str);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
