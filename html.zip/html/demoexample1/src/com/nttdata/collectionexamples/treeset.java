package com.nttdata.collectionexamples;

//import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class treeset {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Set<Integer> st=new TreeSet<Integer>();
		st.add(10);
		st.add(10000);
		st.add(1000000);
		st.add(100);
		st.add(1000);
		//st.add("String123");
		//st.add(66.88);
		//st.add(true);
		//st.add(99.99f);
		//st.add(10);
		Iterator itr=st.iterator();
		while(itr.hasNext())
		{
		System.out.println(itr.next());	
		}
	}

}
