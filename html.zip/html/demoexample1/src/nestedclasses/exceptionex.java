package nestedclasses;

import java.util.Scanner;

public class exceptionex {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[]  marks=new int[5];
int a,b;
Scanner sc=new Scanner(System.in);
System.out.println("enter array elements");

try{
for(int i=0;i<10;i++)
{
marks[i]=sc.nextInt();	
}}
catch(Exception e)
{
	e.printStackTrace();
System.out.println("stack is printed");	
}
		
		
	}

}
