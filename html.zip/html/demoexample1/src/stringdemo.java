
public class stringdemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1="hello how are you";
		String str2="hello how are you";
		String comp1="nttdata";
		String comp2="nttdata";
		String comp3="nttData";
boolean b=comp1.equals(comp2);
System.out.println(b);
int x=str1.indexOf('e');
System.out.println(x);
int y=str1.lastIndexOf('e');
System.out.println(y);

	}

}
