package reflectionexamples;

import java.lang.reflect.Field;

public class samplefield {

	/**
	 * @param args
	 */
	
	static void printfield(Object o)
	{
		
		Class c=o.getClass();
		Field[] f=c.getFields();
		for(int i=0;i<f.length;i++)
		{
			String fieldname=f[i].getName();
			Class c1=f[i].getType();
			String fieldtype=c1.getName();
		
		System.out.println("field name"+fieldname+"type"+fieldtype);
		}
			
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		kid k=new kid();
		printfield(k);
	}

}
