public class demo123{
public static void main(String argv[]){
	String a = null;
	System.out.println (a);
}}