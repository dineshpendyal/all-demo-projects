package com.nttdata.course.dao;
import com.ntt.dbcon.*;
import com.ntt.dbfw.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import com.nttdata.course.domain.*;
//import com.ntt.dao.*;

import com.ntt.dbcon.connectionholder;
import com.nttdata.course.domain.user;

public class userdao {

public static user validateuser(final String x,final String y) throws coursedaoexception
{
	user user=null;
try{
	
	connectionholder chobj=null;
	Connection con=null;
	ResultMapper rs=null;
	
	
	chobj=connectionholder.getInstance();
    con=chobj.getConnection();
    
  
final ParamMapper getroleid=new com.ntt.dbfw.ParamMapper()
    {
        public void mapParam(PreparedStatement preStmt) throws SQLException 
      {
	    preStmt.setString(1, x);
	    preStmt.setString(2, y);
	    
		}

   };

     System.out.println("after final  paramapper");
	
     //String a="select userid,username,password,roleid from userdetails where userid=? and password=?";
   List roleid;
   //  List roleid=DBHelper.executeSelect(con,a,rs);
     //System.out.println(roleid);
     //System.out.println("dinesh");
   roleid = DBHelper.executeSelect(con,SQLMapper.VALIDATE_USER,SQLMapper.MAP_Student);
	System.out.println(roleid);
//	System.out.println(roleid);
	Iterator itr=roleid.iterator();
	while(itr.hasNext())
	{
		
		//System.out.println(itr.next());
		 user=(user) itr.next();
		 
		if(user.getUserid().equals(x))
		{
			return  user;
		}
	}

			
	
} 
catch (dbconnectionexception e)
{
	System.out.println("in userdaoexception");
	//throw new dbconnectionexception("not a user");

}
//finally {
 catch (DBFWException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

//	try {
//
//		if (con != null)
//			con.close();
//
//	} 
	
//	catch (SQLException e) 
//	{
//	System.out.println("in userdaoexception");
//	}
//}
return  user;

}
}
