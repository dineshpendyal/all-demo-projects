package com.nttdata;

class Student3
{   
	private int sid;
	private int avg_marks;
	
	void display( Student3 s)
	{
		 System.out.println("welcome "+s.name);
		 System.out.println("Your avg marks "+s.avg_marks);
	}
	
	public Student3()
	{
		
	}
	
	
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public int getAvg_marks() {
		return avg_marks;
	}
	public void setAvg_marks(int avg_marks) {
		this.avg_marks = avg_marks;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	private String name;
	
}

public class PojoEx {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Student3 std = new Student3();
     System.out.println("Student id");
     std.setSid(10);
     std.setName("student1");
     std.setAvg_marks(70);
     
     std.display(std);
     
   }
}
