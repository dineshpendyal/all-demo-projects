package domain;

import java.util.List;

public class StudPreference {
private String StudId;
private List  prefCourse;
int pCount=0;
int sCount=0;
public String getStudId() {
	return StudId;
}
public boolean addPref(String courseId, String preference){

	
	if(preference.equals("p")&&pCount<=4){
		pCount++;
		System.out.println(pCount);
		return true;
	}
	
	if(preference.equals("s")&&sCount<=2){
		sCount++;
		System.out.println(sCount);
		return true;
	}
	return false;
}

public void setStudId(String studId) {
	StudId = studId;
}

public List  getprefCourse() {
	return prefCourse;
}

public List setprefCourse(List coursePreference) {
	//prefCourse = prefCourse;

	return coursePreference;
}

public StudPreference(String studId, List prefCourse) {
	super();
	StudId = studId;
	this.prefCourse = prefCourse;
}

//public int addPref(StudPreference studPref) {
//	// TODO Auto-generated method stub
//	return 0;
//}


}
