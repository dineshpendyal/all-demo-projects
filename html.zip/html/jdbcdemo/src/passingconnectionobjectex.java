import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;


public class passingconnectionobjectex {

	/**
	 * @param args
	 */
static void read(Connection con,Statement stmt,String query)
{
try
{
	stmt=con.createStatement();
	int x=stmt.executeUpdate(query);
	System.out.println(x);
}

catch(Exception e)
 {
 System.out.println(e);
 }

}

	

}
