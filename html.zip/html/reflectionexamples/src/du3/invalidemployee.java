package du3;

public class invalidemployee extends Exception {

	/**
	 * @param args
	 */
	String emp_id;
	void readDetails(invalidemployee i)throws invalidemployee
	{
		
		if(emp_id=="null")
		{
			throw new invalidemployee();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
invalidemployee u=new invalidemployee();
u.emp_id="null";
try
{
	u.readDetails(u);

}
catch(invalidemployee e)
{
	System.out.println(e);
}

}}


