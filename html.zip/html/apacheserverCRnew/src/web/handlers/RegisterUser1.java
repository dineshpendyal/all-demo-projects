package web.handlers;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;
import mvc.HttpRequestHandler;
import dao.DAOAppException;
import dao.RegisterDAO;
import domain.user;

public class RegisterUser1 implements HttpRequestHandler {
	static Logger log = Logger.getLogger(RegisterUser1.class);

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RegisterDAO dao = new RegisterDAO();
		user user = new user();
		//user.setUserId(Integer.parseInt(request.getParameter("userid")));
		user.setUserId(request.getParameter("userid"));
		user.setUserName(request.getParameter("username"));
		user.setPassword(request.getParameter("password"));
		user.setRoleId(request.getParameter("roleid"));
		
		
		try{
		int finalRes = dao.registerUser(user);
		if (finalRes > 0) {
					
			RequestDispatcher dispatcher = request.getRequestDispatcher("..\\pages\\success.jsp");
			request.setAttribute("success","User succesfully registered with the system");
			request.setAttribute("details", user);
			dispatcher.forward(request, response);
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		
		
		
		
		

//		boolean isExists;
//		try {
//			isExists = dao.validateUser(user.getUserId());
//
//			if (isExists) {
//				log.info("User already registered");
//				RequestDispatcher dispatcher = request
//						.getRequestDispatcher("..\\pages\\Login.jsp");
//				request.setAttribute("Err",
//						"User already registered with the system");
//				dispatcher.forward(request, response);
//			} 
//			
//			else 
//			{
//				user.setPassword("NttData@" +(user.getUserId()));
//				int finalRes = dao.registerUser(user);
//				if (finalRes > 0) {
//							
//					RequestDispatcher dispatcher = request.getRequestDispatcher("..\\pages\\success.jsp");
//					request.setAttribute("success","User succesfully registered with the system");
//					request.setAttribute("details", user);
//					dispatcher.forward(request, response);
//				}
//			}
//		} 
//		
//		
//		
//		
//		
//		
//		
//		catch (DAOAppException e) {
//			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
//			request.setAttribute("Err",e.getMessage());
//			dispatcher.forward(request,response);
//		}
	}

}
