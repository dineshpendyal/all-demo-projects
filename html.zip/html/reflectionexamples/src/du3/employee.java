package du3;

import java.util.ArrayList;
import java.util.Iterator;

//try
//{

public class employee  {
	public int eid,salary;
	public String projectname;

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getProjectname() {
		return projectname;
	}

	public void setProjectname(String projectname) {
		this.projectname = projectname;
	}
//}
//}
//catch(Exception e)
//{
//System.out.println(e);	
//}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ArrayList list1 = new ArrayList();
employee e1=new employee();
//employee e2=new employee();
//employee e3=new employee();
e1.setEid(10);
e1.setProjectname("java");
e1.setSalary(10000);
//e1.eid=10;
//e1.salary=10000;
//e1.projectname="javaproj";

//e2.eid=10;
//e2.salary=10000;
//e2.projectname="javaproj1";
//
//e3.eid=10;
//e3.salary=10000;
//e3.projectname="javaproj2";
list1.add(e1);

Iterator itr = list1.iterator(); 


while (itr.hasNext()) 
{
	employee obj=(employee)itr.next();
	
	System.out.println(obj.eid);
	System.out.println(obj.projectname);
	System.out.println(obj.salary);
	
	//System.out.print(((itr.next() + "")); 
	//System.out.println(list.get(e1));
	
}

//list.add(e2);

//list.add(e3);




//Iterator iterator=

//Object list;
//Iterator iterator = list.iterator(); 

//System.out.println("using iterator : "); 
//
//while (iterator.hasNext()) 
//{
//	System.out.print(iterator.next() + " "); 
//}
//System.out.println(""); 
	
	}

}
